import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Login from './components/Login';
import AdminDashboard from './components/AdminDashboard';
import AdminSocietyPosts from './components/AdminSocietyPosts';
import SocietyDashboard from './components/SocietyDashboard';
import StudentDashboard from './components/StudentDashboard';
import SocietyMembers from './components/SocietyMembers';
import SocietyProfile from './components/SocietyProfile';
import SocietyPosts from './components/SocietyPosts';
import SocietyAnnouncements from './components/SocietyAnnouncements';
import SocietyEvents from './components/SocietyEvents';
import StudentProfile from './components/StudentProfile';

function App() {
  const [user, setUser] = React.useState(() => {
    const savedUser = localStorage.getItem('user');
    return savedUser ? JSON.parse(savedUser) : null;
  });

  useEffect(() => {
    if (user) {
      localStorage.setItem('user', JSON.stringify(user));
    }
  }, [user]);

  const handleLogin = (userData) => {
    setUser(userData);
    localStorage.setItem('user', JSON.stringify(userData));
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  // Protected Route component
  const ProtectedRoute = ({ children, allowedUserType }) => {
    if (!user) {
      return <Navigate to="/login" />;
    }

    if (allowedUserType && user.type !== allowedUserType) {
      return <Navigate to="/dashboard" />;
    }

    return children;
  };

  // Get default dashboard route based on user type
  const getDashboardComponent = () => {
    if (!user) return <Navigate to="/login" />;

    switch (user.type) {
      case 'Admin':
        return <Navigate to="/admin/dashboard" />;
      case 'Society':
        return <Navigate to="/society/dashboard" />;
      case 'Student':
        return <Navigate to="/student/dashboard" />;
      default:
        return <Navigate to="/login" />;
    }
  };

  return (
    <Router>
      <div>
        <Routes>
          {/* Public Routes */}
          <Route 
            path="/login" 
            element={user ? <Navigate to="/dashboard" /> : <Login onLogin={handleLogin} />} 
          />
          <Route path="/" element={<Navigate to="/dashboard" />} />
          
          {/* Dashboard Redirect */}
          <Route path="/dashboard" element={getDashboardComponent()} />

          {/* Student Routes */}
          <Route
            path="/student/dashboard"
            element={
              <ProtectedRoute allowedUserType="Student">
                <StudentDashboard user={user} onLogout={handleLogout} />
              </ProtectedRoute>
            }
          />
          <Route
            path="/student/profile"
            element={
              <ProtectedRoute allowedUserType="Student">
                <StudentProfile user={user} onLogout={handleLogout} />
              </ProtectedRoute>
            }
          />

          {/* Society Routes */}
          <Route
            path="/society/dashboard"
            element={
              <ProtectedRoute allowedUserType="Society">
                <SocietyMembers user={user} onLogout={handleLogout} />
              </ProtectedRoute>
            }
          />
          <Route
            path="/society/profile"
            element={
              <ProtectedRoute allowedUserType="Society">
                <SocietyProfile user={user} onLogout={handleLogout} />
              </ProtectedRoute>
            }
          />
          <Route
            path="/society/posts"
            element={
              <ProtectedRoute allowedUserType="Society">
                <SocietyPosts user={user} onLogout={handleLogout} />
              </ProtectedRoute>
            }
          />
          <Route
            path="/society/announcements"
            element={
              <ProtectedRoute allowedUserType="Society">
                <SocietyAnnouncements user={user} onLogout={handleLogout} />
              </ProtectedRoute>
            }
          />
          <Route
            path="/society/events"
            element={
              <ProtectedRoute allowedUserType="Society">
                <SocietyEvents user={user} onLogout={handleLogout} />
              </ProtectedRoute>
            }
          />

          {/* Admin Routes */}
          <Route
            path="/admin/dashboard"
            element={
              <ProtectedRoute allowedUserType="Admin">
                <AdminDashboard user={user} onLogout={handleLogout} />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/posts"
            element={
              <ProtectedRoute allowedUserType="Admin">
                <AdminSocietyPosts user={user} onLogout={handleLogout} />
              </ProtectedRoute>
            }
          />

          {/* Catch all route */}
          <Route path="*" element={<Navigate to="/dashboard" />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
 