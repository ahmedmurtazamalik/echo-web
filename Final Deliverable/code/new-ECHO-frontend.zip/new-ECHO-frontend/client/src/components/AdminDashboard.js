import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Navbar from './Navbar';
import '../styles/global.css';

function AdminDashboard({ user, onLogout }) {
  const [societies, setSocieties] = useState([]);
  const [pendingEvents, setPendingEvents] = useState([]);
  const [allEvents, setAllEvents] = useState([]);
  const [newSociety, setNewSociety] = useState({ 
    name: '', 
    description: '',
    category: ''
  });
  const [selectedSociety, setSelectedSociety] = useState(null);
  const [newVenue, setNewVenue] = useState({
    name: '',
    capacity: '',
    location: ''
  });
  const [venues, setVenues] = useState([]);

  useEffect(() => {
    fetchSocieties();
    fetchPendingEvents();
    fetchVenues();
    fetchAllEvents();
  }, []);

  const fetchSocieties = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/admin/societies');
      setSocieties(response.data);
    } catch (error) {
      alert('Error fetching societies: ' + error.message);
    }
  };

  const fetchPendingEvents = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/admin/events/pending');
      console.log('Pending events:', response.data); // Debug log
      setPendingEvents(response.data);
    } catch (error) {
      console.error('Error fetching pending events:', error);
      alert('Error fetching pending events: ' + error.message);
    }
  };

  const fetchVenues = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/admin/venues');
      setVenues(response.data);
    } catch (error) {
      console.error('Error fetching venues:', error);
    }
  };

  const fetchAllEvents = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/admin/events/all');
      setAllEvents(response.data);
    } catch (error) {
      console.error('Error fetching all events:', error);
    }
  };

  const handleApprove = async (id) => {
    try {
      await axios.post(`http://localhost:5000/api/admin/societies/${id}/approve`);
      fetchSocieties();
    } catch (error) {
      alert('Error approving society: ' + error.message);
    }
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/api/admin/societies/${id}`);
      fetchSocieties();
      setSelectedSociety(null);
    } catch (error) {
      alert('Error deleting society: ' + error.message);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/societies', newSociety);
      setNewSociety({ name: '', description: '', category: '' });
      fetchSocieties();
    } catch (error) {
      alert('Error creating society: ' + error.message);
    }
  };

  const handleViewSociety = async (society) => {
    setSelectedSociety(society);
  };

  const handleDeletePost = async (societyId, postIndex) => {
    try {
      const society = societies.find(s => s._id === societyId);
      if (!society) return;

      const updatedPosts = society.posts.filter((_, index) => index !== postIndex);
      await axios.put(`http://localhost:5000/api/admin/societies/${societyId}/posts`, {
        posts: updatedPosts
      });
      
      fetchSocieties();
      setSelectedSociety(prev => ({
        ...prev,
        posts: updatedPosts
      }));
    } catch (error) {
      alert('Error deleting post: ' + error.message);
    }
  };

  const handleEventAction = async (eventId, societyId, action) => {
    try {
      console.log('Event action:', { eventId, societyId, action }); // Debug log
      const status = action === 'approve' ? 'approved' : 'rejected';
      const response = await axios.put(`http://localhost:5000/api/societies/${societyId}/events/${eventId}`, {
        status
      });
      console.log('Event action response:', response.data); // Debug log
      
      // Refresh both pending and all events
      await Promise.all([
        fetchPendingEvents(),
        fetchAllEvents()
      ]);
      
      alert(`Event ${action}d successfully`);
    } catch (error) {
      console.error('Error handling event action:', error);
      alert(`Error ${action}ing event: ${error.response?.data?.message || error.message}`);
    }
  };

  const handleAddVenue = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/admin/venues', newVenue);
      setNewVenue({ name: '', capacity: '', location: '' });
      fetchVenues();
    } catch (error) {
      alert(error.response?.data?.message || 'Error adding venue');
    }
  };

  const handleDeleteVenue = async (venueName) => {
    if (window.confirm('Are you sure you want to delete this venue? This will affect all societies.')) {
      try {
        await axios.delete(`http://localhost:5000/api/admin/venues/${venueName}`);
        fetchVenues();
      } catch (error) {
        alert(error.response?.data?.message || 'Error deleting venue');
      }
    }
  };

  return (
    <div className="dashboard fade-in">
      <Navbar userType="Admin" user={user} onLogout={onLogout} />
      
      <div className="container">
        <div className="dashboard-header">
          <h2>Admin Dashboard</h2>
        </div>

        {/* Pending Events Section */}
        <div className="card">
          <h3>Pending Events</h3>
          <div className="grid">
            {pendingEvents.map((event, index) => (
              <div key={index} className="event-card">
                <h4>{event.name}</h4>
                <p>{event.description}</p>
                <p>Society: {event.societyName}</p>
                <p>Date: {new Date(event.date).toLocaleDateString()}</p>
                <p>Time: {event.startTime} - {event.endTime}</p>
                <p>Venue: {event.venue}</p>
                <div className="btn-group">
                  <button 
                    onClick={() => handleEventAction(event._id, event.societyId, 'approve')}
                    className="btn btn-success"
                  >
                    Approve
                  </button>
                  <button 
                    onClick={() => handleEventAction(event._id, event.societyId, 'reject')}
                    className="btn btn-error"
                  >
                    Reject
                  </button>
                </div>
              </div>
            ))}
            {pendingEvents.length === 0 && (
              <p>No pending events</p>
            )}
          </div>
        </div>

        <div className="grid">
          {/* Left Column */}
          <div className="card">
          <h3>Add New Society</h3>
          <form onSubmit={handleSubmit}>
              <div className="form-group">
              <label>Name:</label>
              <input
                type="text"
                value={newSociety.name}
                onChange={(e) => setNewSociety({ ...newSociety, name: e.target.value })}
                required
              />
            </div>
              <div className="form-group">
                <label>Category:</label>
                <select
                  value={newSociety.category}
                  onChange={(e) => setNewSociety({ ...newSociety, category: e.target.value })}
                  required
                  className="select-input"
                >
                  <option value="">Select Category</option>
                  <option value="Academic">Academic</option>
                  <option value="Sports">Sports</option>
                  <option value="Cultural">Cultural</option>
                  <option value="Technical">Technical</option>
                  <option value="Social">Social</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              <div className="form-group">
              <label>Description:</label>
              <textarea
                value={newSociety.description}
                onChange={(e) => setNewSociety({ ...newSociety, description: e.target.value })}
                required
              />
            </div>
              <button type="submit" className="btn">Add Society</button>
          </form>
          </div>

          {/* Right Column */}
          <div className="card">
            <h3>Add New Venue</h3>
            <form onSubmit={handleAddVenue}>
              <div className="form-group">
                <label>Name:</label>
                <input
                  type="text"
                  value={newVenue.name}
                  onChange={(e) => setNewVenue({ ...newVenue, name: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>Capacity:</label>
                <input
                  type="number"
                  value={newVenue.capacity}
                  onChange={(e) => setNewVenue({ ...newVenue, capacity: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>Location:</label>
                <input
                  type="text"
                  value={newVenue.location}
                  onChange={(e) => setNewVenue({ ...newVenue, location: e.target.value })}
                  required
                />
              </div>
              <button type="submit" className="btn">Add Venue</button>
            </form>
          </div>
        </div>

        {/* Venues Section */}
        <div className="card">
          <h3>Venues</h3>
          <div className="grid">
              {venues.map((venue, index) => (
              <div key={index} className="venue-card">
                  <h4>{venue.name}</h4>
                  <p>Capacity: {venue.capacity}</p>
                  <p>Location: {venue.location}</p>
                  <button 
                  onClick={() => handleDeleteVenue(venue._id)}
                  className="btn btn-error"
                  >
                    Delete Venue
                  </button>
                </div>
              ))}
            </div>
          </div>

        {/* Societies Section */}
        <div className="card">
          <h3>Societies</h3>
          <div className="grid">
            {societies.map((society) => (
              <div key={society._id} className="society-card">
                <h4>{society.name}</h4>
                <p>{society.description}</p>
                <p>Status: {society.isApproved ? 'Approved' : 'Pending Approval'}</p>
                <div className="btn-group">
                  {!society.isApproved && (
                    <button 
                      onClick={() => handleApprove(society._id)}
                      className="btn btn-success"
                    >
                      Approve
                    </button>
                  )}
                  <button 
                    onClick={() => handleDelete(society._id)}
                    className="btn btn-error"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* All Events Section */}
        <div className="card">
          <h3>All Events</h3>
          <div className="grid">
            {allEvents.map((event, index) => (
              <div key={index} className="event-card">
                <h4>{event.name}</h4>
                <p>{event.description}</p>
                <p>Society: {event.societyName}</p>
                <p>Date: {new Date(event.date).toLocaleDateString()}</p>
                <p>Time: {event.startTime} - {event.endTime}</p>
                <p>Venue: {event.venue}</p>
                <p className={`badge ${
                  event.status === 'approved' ? 'badge-success' :
                  event.status === 'rejected' ? 'badge-error' :
                  'badge-warning'
                }`}>
                  Status: {event.status.charAt(0).toUpperCase() + event.status.slice(1)}
                </p>
                    </div>
                  ))}
            {allEvents.length === 0 && (
              <p>No events found</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default AdminDashboard; 