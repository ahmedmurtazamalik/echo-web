import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Navbar from './Navbar';
import '../styles/global.css';

function AdminSocietyPosts({ user, onLogout }) {
  const [posts, setPosts] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [selectedSociety, setSelectedSociety] = useState(null);
  const [societies, setSocieties] = useState([]);
  const [showMessageModal, setShowMessageModal] = useState(false);

  useEffect(() => {
    fetchPosts();
    fetchSocieties();
  }, []);

  const fetchPosts = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/admin/societies/posts');
      setPosts(response.data);
    } catch (error) {
      console.error('Error fetching posts:', error);
    }
  };

  const fetchSocieties = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/admin/societies');
      setSocieties(response.data);
    } catch (error) {
      console.error('Error fetching societies:', error);
    }
  };

  const handleDeletePost = async (societyId, postIndex) => {
    try {
      await axios.delete(`http://localhost:5000/api/admin/societies/${societyId}/posts/${postIndex}`);
      fetchPosts();
    } catch (error) {
      console.error('Error deleting post:', error);
    }
  };

  const handleSendMessage = async () => {
    try {
      await axios.post(`http://localhost:5000/api/admin/societies/${selectedSociety._id}/messages`, {
        content: newMessage
      });
      setNewMessage('');
      setShowMessageModal(false);
      setSelectedSociety(null);
      fetchPosts();
    } catch (error) {
      console.error('Error sending message:', error);
    }
  };

  return (
    <div className="dashboard fade-in">
      <Navbar userType="Admin" user={user} onLogout={onLogout} />
      
      <div className="container">
        <div className="header-actions">
          <h2>Society Posts</h2>
          <button 
            className="btn btn-primary"
            onClick={() => setShowMessageModal(true)}
          >
            Send Message to Society
          </button>
        </div>

        <div className="posts-grid">
          {posts.map((post, index) => (
            <div key={index} className="post-card">
              <div className="post-header">
                <h3>{post.societyName}</h3>
                {post.isAdminMessage && <span className="badge badge-primary">Admin Message</span>}
                {post.isAnnouncement && <span className="badge badge-warning">Announcement</span>}
              </div>
              <p>{post.content}</p>
              <div className="post-footer">
                <small>{new Date(post.createdAt).toLocaleString()}</small>
                <button 
                  onClick={() => handleDeletePost(post.societyId, index)}
                  className="btn btn-error"
                >
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Message Modal */}
      {showMessageModal && (
        <div className="modal">
          <div className="modal-content card">
            <h3>Send Message to Society</h3>
            <select
              value={selectedSociety?._id || ''}
              onChange={(e) => setSelectedSociety(societies.find(s => s._id === e.target.value))}
              className="select-input"
            >
              <option value="">Select Society</option>
              {societies.map(society => (
                <option key={society._id} value={society._id}>
                  {society.name}
                </option>
              ))}
            </select>
            <textarea
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Enter your message..."
              className="textarea"
              maxLength={1000}
            />
            <div className="char-count">
              {newMessage.length}/1000 characters
            </div>
            <div className="modal-actions">
              <button 
                onClick={handleSendMessage}
                disabled={!selectedSociety || !newMessage.trim()}
                className="btn btn-success"
              >
                Send
              </button>
              <button 
                onClick={() => {
                  setShowMessageModal(false);
                  setSelectedSociety(null);
                  setNewMessage('');
                }}
                className="btn"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      <style>
        {`
          .header-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
          }

          .posts-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 1.5rem;
          }

          .post-card {
            background: var(--bg-secondary);
            padding: 1.5rem;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
          }

          .post-header {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 1rem;
          }

          .post-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 1rem;
          }

          .badge {
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            font-size: 0.8rem;
          }

          .badge-primary {
            background: var(--accent-blue);
            color: white;
          }

          .badge-warning {
            background: var(--warning);
            color: white;
          }

          .modal-actions {
            display: flex;
            gap: 1rem;
            margin-top: 1rem;
          }

          .textarea {
            min-height: 120px;
            margin: 1rem 0;
          }

          .char-count {
            font-size: 0.8rem;
            color: var(--text-gray);
            text-align: right;
            margin-top: 0.25rem;
          }
        `}
      </style>
    </div>
  );
}

export default AdminSocietyPosts; 