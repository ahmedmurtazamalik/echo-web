import React from 'react';
import { useNavigate } from 'react-router-dom';

function AnimatedHeader({ userType }) {
  const navigate = useNavigate();

  const handleClick = () => {
    navigate('/dashboard');
  };

  return (
    <div className="animated-header">
      <h1 className="app-title" onClick={handleClick}>
        <span className="letter">E</span>
        <span className="letter">C</span>
        <span className="letter">H</span>
        <span className="letter">O</span>
      </h1>

      <style>
        {`
          .animated-header {
            padding: 0.8rem;
            text-align: center;
            background: linear-gradient(135deg, #001f3f, #0066cc, #ffffff);
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.15);
            position: relative;
            overflow: hidden;
            z-index: 100;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
          }

          .animated-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 2px;
            background: linear-gradient(90deg, transparent, #e6f3ff, transparent);
            animation: loading 3s linear infinite;
            box-shadow: 0 0 15px rgba(230, 243, 255, 0.5);
          }

          .app-title {
            font-size: 2.5rem;
            font-weight: bold;
            color: white;
            cursor: pointer;
            display: inline-block;
            margin: 0;
            padding: 0.3rem 1rem;
            position: relative;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2);
          }

          .letter {
            display: inline-block;
            transition: transform 0.3s ease, color 0.3s ease;
            position: relative;
            color: #ffffff;
          }

          .letter:hover {
            transform: translateY(-5px) rotate(5deg);
            color: #e6f3ff;
            text-shadow: 
              0 0 10px #ffffff,
              0 0 20px #99ccff,
              0 0 30px #0066cc;
          }

          .app-title:hover .letter {
            animation: bounce 0.5s ease infinite;
            animation-delay: calc(0.1s * var(--i));
          }

          @keyframes loading {
            0% {
              left: -100%;
            }
            100% {
              left: 100%;
            }
          }

          @keyframes bounce {
            0%, 100% {
              transform: translateY(0);
            }
            50% {
              transform: translateY(-10px);
            }
          }

          /* Blue gradient for letters */
          .letter:nth-child(1) { --i: 1; color: #ffffff; }
          .letter:nth-child(2) { --i: 2; color: #e6f3ff; }
          .letter:nth-child(3) { --i: 3; color: #cce6ff; }
          .letter:nth-child(4) { --i: 4; color: #b3d9ff; }

          /* Responsive design */
          @media (max-width: 768px) {
            .app-title {
              font-size: 2rem;
            }
            .animated-header {
              padding: 0.6rem;
            }
          }
        `}
      </style>
    </div>
  );
}

export default AnimatedHeader; 