import React, { useState } from 'react';
import axios from 'axios';
import AnimatedHeader from './AnimatedHeader';
import '../styles/global.css';

function Login({ onLogin }) {
  const [rollNumber, setRollNumber] = useState('');
  const [password, setPassword] = useState('');
  const [userType, setUserType] = useState('Student');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    try {
      const response = await axios.post('http://localhost:5000/api/login', {
        rollNumber,
        password,
        type: userType
      });

      onLogin(response.data);
    } catch (error) {
      setError(error.response?.data?.message || 'Login failed. Please try again.');
    }
  };

  return (
    <div className="login-container">
      <AnimatedHeader />
      
      <div className="login-card card">
        <h2>Login</h2>
        {error && <div className="error-message">{error}</div>}
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>User Type</label>
            <select
              className="select-input"
              value={userType}
              onChange={(e) => setUserType(e.target.value)}
            >
              <option value="Student">Student</option>
              <option value="Society">Society</option>
              <option value="Admin">Admin</option>
            </select>
          </div>
          <div className="form-group">
            <label>
              {userType === 'Student' ? 'Roll Number' : 
               userType === 'Society' ? 'Society Name' : 
               'Admin Username'}
            </label>
            <input
              type="text"
              value={rollNumber}
              onChange={(e) => setRollNumber(e.target.value)}
              placeholder={
                userType === 'Student' ? 'Enter roll number' :
                userType === 'Society' ? 'Enter society name' :
                'Enter admin username'
              }
              required
            />
          </div>
          <div className="form-group">
            <label>Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter password"
              required
            />
          </div>
          <button type="submit" className="btn">
            Login
          </button>
        </form>
      </div>

      <style>
        {`
          .login-container {
            min-height: 100vh;
            background-color: var(--primary-black);
            display: flex;
            flex-direction: column;
          }

          .login-card {
            max-width: 400px;
            margin: 2rem auto;
            background-color: var(--secondary-black);
          }

          .select-input {
            width: 100%;
            padding: 0.8rem;
            border-radius: 4px;
            border: 1px solid var(--text-gray);
            background-color: var(--secondary-black);
            color: var(--text-white);
            font-family: 'Roboto Mono', monospace;
            cursor: pointer;
          }

          .select-input:focus {
            outline: none;
            border-color: var(--accent-blue);
          }

          .form-group {
            margin-bottom: 1.5rem;
          }

          .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            color: var(--text-gray);
          }

          .error-message {
            background: rgba(220, 53, 69, 0.1);
            color: #dc3545;
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 1.5rem;
            border: 1px solid rgba(220, 53, 69, 0.2);
            font-size: 0.9rem;
            white-space: pre-line;
          }
        `}
      </style>
    </div>
  );
}

export default Login; 