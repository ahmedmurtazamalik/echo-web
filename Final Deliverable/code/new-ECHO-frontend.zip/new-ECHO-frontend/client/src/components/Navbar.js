import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';
import AnimatedHeader from './AnimatedHeader';
import '../styles/global.css';

function Navbar({ userType, user, onLogout }) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [profilePicture, setProfilePicture] = useState('');
  const navigate = useNavigate();
  const menuRef = useRef(null);
  const hamburgerRef = useRef(null);

  useEffect(() => {
    if (userType === 'Student') {
      fetchProfilePicture();
    }

    // Add click outside handler
    const handleClickOutside = (event) => {
      if (
        menuRef.current && 
        !menuRef.current.contains(event.target) &&
        !hamburgerRef.current.contains(event.target)
      ) {
        setIsMenuOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [userType, user]);

  const fetchProfilePicture = async () => {
    try {
      const response = await axios.get(`http://localhost:5000/api/students/${user.rollNumber}/profile`);
      if (response.data.profilePhoto) {
        setProfilePicture(`http://localhost:5000/${response.data.profilePhoto}`);
      }
    } catch (error) {
      console.error('Error fetching profile picture:', error);
    }
  };

  const handleNavigation = (path) => {
    setIsMenuOpen(false);
    if (path === '/logout') {
      handleLogout();
    } else {
      navigate(path);
    }
  };

  const handleLogout = () => {
    setIsMenuOpen(false);
    onLogout();
    navigate('/login');
  };

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const getNavItems = () => {
    switch (userType) {
      case 'Student':
        return [
          { label: 'Dashboard', path: '/dashboard' },
          { label: 'Profile', path: '/student/profile' }
        ];
      case 'Society':
        return [
          { label: 'Members', path: '/society/dashboard' },
          { label: 'Profile', path: '/society/profile' },
          { label: 'Posts', path: '/society/posts' },
          { label: 'Announcements', path: '/society/announcements' },
          { label: 'Events', path: '/society/events' }
        ];
      case 'Admin':
        return [
          { label: 'Dashboard', path: '/admin/dashboard' },
          { label: 'Society Posts', path: '/admin/posts' },
          { label: 'Societies', path: '/admin/societies' },
          { label: 'Venues', path: '/admin/venues' },
          { label: 'Events', path: '/admin/events' }
        ];
      default:
        return [];
    }
  };

  return (
    <>
      <AnimatedHeader userType={userType} />
      <header className="app-header">
        <div className="header-right">
          {userType === 'Student' && (
            <div 
              className="profile-picture-small" 
              onClick={() => handleNavigation('/student/profile')}
            >
              {profilePicture ? (
                <img src={profilePicture} alt="Profile" />
              ) : (
                <div className="profile-placeholder">
                  {user.name.charAt(0).toUpperCase()}
                </div>
              )}
            </div>
          )}
          <div 
            ref={hamburgerRef}
            className={`hamburger ${isMenuOpen ? 'active' : ''}`} 
            onClick={toggleMenu}
          >
            <span></span>
            <span></span>
            <span></span>
          </div>
        </div>
      </header>

      <nav ref={menuRef} className={`nav-menu ${isMenuOpen ? 'active' : ''}`}>
        <div className="nav-content">
          <ul className="nav-links">
            {getNavItems().map((item, index) => (
              <li key={index}>
                <Link 
                  to={item.path}
                  onClick={() => setIsMenuOpen(false)}
                  className={window.location.pathname === item.path ? 'active' : ''}
                >
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
          <div className="nav-footer">
            <button 
              className="btn btn-error logout-btn"
              onClick={() => handleLogout()}
            >
              Logout
            </button>
          </div>
        </div>
      </nav>

      <style>
        {`
          .app-header {
            display: flex;
            justify-content: flex-end;
            padding: 1rem;
            background: var(--bg-secondary);
            border-bottom: 1px solid var(--border-color);
          }

          .header-right {
            display: flex;
            align-items: center;
            gap: 1rem;
          }

          .profile-picture-small {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            overflow: hidden;
            cursor: pointer;
            border: 2px solid var(--accent-blue);
            transition: transform var(--transition-speed);
          }

          .profile-picture-small:hover {
            transform: scale(1.1);
          }

          .profile-picture-small img {
            width: 100%;
            height: 100%;
            object-fit: cover;
          }

          .profile-placeholder {
            width: 100%;
            height: 100%;
            background: var(--gradient-blue);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 1.2rem;
            color: var(--text-white);
          }

          .nav-content {
            height: 100%;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
          }

          .nav-links {
            flex-grow: 1;
          }

          .nav-footer {
            padding: 1rem;
            border-top: 1px solid var(--text-gray);
          }

          .logout-btn {
            width: 100%;
          }

          .nav-menu a.active {
            color: var(--accent-blue);
            font-weight: bold;
          }
        `}
      </style>
    </>
  );
}

export default Navbar; 