import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Navbar from './Navbar';
import '../styles/global.css';

function SocietyAnnouncements({ user, onLogout }) {
  const [society, setSociety] = useState(null);
  const [newAnnouncement, setNewAnnouncement] = useState({
    content: '',
    scheduledFor: ''
  });
  const [upcomingAnnouncements, setUpcomingAnnouncements] = useState([]);

  const fetchSocietyData = async () => {
    try {
      const response = await axios.get(`http://localhost:5000/api/societies/${user.name}`);
      setSociety(response.data);
    } catch (error) {
      console.error('Error fetching society data:', error);
    }
  };

  const fetchUpcomingAnnouncements = async () => {
    try {
      const response = await axios.get(`http://localhost:5000/api/societies/${society?._id}/announcements/upcoming`);
      setUpcomingAnnouncements(response.data);
    } catch (error) {
      console.error('Error fetching upcoming announcements:', error);
    }
  };

  useEffect(() => {
    if (user) {
      fetchSocietyData();
    }
  }, [user]);

  useEffect(() => {
    if (society) {
      fetchUpcomingAnnouncements();
    }
  }, [society]);

  const handleScheduleAnnouncement = async (e) => {
    e.preventDefault();
    try {
      await axios.post(`http://localhost:5000/api/societies/${society._id}/announcements`, newAnnouncement);
      setNewAnnouncement({ content: '', scheduledFor: '' });
      fetchUpcomingAnnouncements();
      alert('Announcement scheduled successfully!');
    } catch (error) {
      alert('Error scheduling announcement: ' + error.message);
    }
  };

  if (!society) {
    return <div>Loading...</div>;
  }

  return (
    <div className="dashboard fade-in">
      <Navbar userType="Society" user={user} onLogout={onLogout} />
      
      <div className="container">
        <div className="card">
          <h3>Schedule New Announcement</h3>
          <form onSubmit={handleScheduleAnnouncement}>
            <div className="form-group">
              <label>Content:</label>
              <textarea
                value={newAnnouncement.content}
                onChange={(e) => setNewAnnouncement({ ...newAnnouncement, content: e.target.value })}
                required
                placeholder="Write your announcement..."
                maxLength={1000}
              />
              <div className="char-count">
                {newAnnouncement.content.length}/1000 characters
              </div>
            </div>
            <div className="form-group">
              <label>Schedule For:</label>
              <input
                type="datetime-local"
                value={newAnnouncement.scheduledFor}
                onChange={(e) => setNewAnnouncement({ ...newAnnouncement, scheduledFor: e.target.value })}
                required
              />
            </div>
            <button type="submit" className="btn">Schedule Announcement</button>
          </form>
        </div>

        {upcomingAnnouncements.length > 0 && (
          <div className="card">
            <h3>Upcoming Announcements</h3>
            <div className="grid">
              {upcomingAnnouncements.map((announcement, index) => (
                <div key={index} className="announcement-card">
                  <p>{announcement.content}</p>
                  <small>Scheduled for: {new Date(announcement.scheduledFor).toLocaleString()}</small>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="card">
          <h3>Past Announcements</h3>
          <div className="grid">
            {society.posts
              .filter(post => post.isAnnouncement)
              .map((announcement, index) => (
                <div key={index} className="announcement-card">
                  <p>{announcement.content}</p>
                  <small>Posted on: {new Date(announcement.createdAt).toLocaleString()}</small>
                </div>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default SocietyAnnouncements;

<style>
{`
  .char-count {
    font-size: 0.8rem;
    color: var(--text-gray);
    text-align: right;
    margin-top: 0.25rem;
  }
`}
</style> 