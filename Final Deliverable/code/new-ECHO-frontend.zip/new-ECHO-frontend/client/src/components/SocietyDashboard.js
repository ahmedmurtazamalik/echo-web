import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import Navbar from './Navbar';
import '../styles/global.css';

function SocietyDashboard({ user, onLogout }) {
  const [society, setSociety] = useState(null);
  const [newPost, setNewPost] = useState({ content: '', isAnnouncement: false });
  const [pendingApplications, setPendingApplications] = useState([]);
  const [selectedMember, setSelectedMember] = useState(null);
  const [memberRoles, setMemberRoles] = useState({});
  const [newEvent, setNewEvent] = useState({
    name: '',
    description: '',
    date: '',
    startTime: '',
    endTime: '',
    venue: ''
  });
  const [venues, setVenues] = useState([]);
  const [upcomingAnnouncements, setUpcomingAnnouncements] = useState([]);
  const [newAnnouncement, setNewAnnouncement] = useState({
    content: '',
    scheduledFor: ''
  });
  const [eventReminders, setEventReminders] = useState([]);
  const [editingPost, setEditingPost] = useState(null);
  const [selectedMemberHistory, setSelectedMemberHistory] = useState(null);
  const [selectedApplicantHistory, setSelectedApplicantHistory] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [uploadingFile, setUploadingFile] = useState(false);
  const [uploadingForPost, setUploadingForPost] = useState(null);
  const [memberDetails, setMemberDetails] = useState([]);

  const fetchSocietyData = useCallback(async () => {
    try {
      const response = await axios.get(`http://localhost:5000/api/societies/${user.name}`);
      setSociety(response.data);
    } catch (error) {
      alert('Error fetching society data: ' + error.message);
    }
  }, [user.name]);

  const fetchPendingApplications = useCallback(async () => {
    try {
      const response = await axios.get(`http://localhost:5000/api/societies/${user.name}/applications`);
      setPendingApplications(response.data);
    } catch (error) {
      alert('Error fetching applications: ' + error.message);
    }
  }, [user.name]);

  const fetchVenues = async () => {
    try {
      const response = await axios.get(`http://localhost:5000/api/admin/venues`);
      setVenues(response.data);
    } catch (error) {
      console.error('Error fetching venues:', error);
    }
  };

  const fetchUpcomingAnnouncements = async () => {
    try {
      const response = await axios.get(`http://localhost:5000/api/societies/${society?._id}/announcements/upcoming`);
      setUpcomingAnnouncements(response.data);
    } catch (error) {
      console.error('Error fetching upcoming announcements:', error);
    }
  };

  const fetchEventReminders = async () => {
    try {
      const response = await axios.get(`http://localhost:5000/api/societies/${society?._id}/events/reminders`);
      setEventReminders(response.data);
    } catch (error) {
      console.error('Error fetching event reminders:', error);
    }
  };

  const fetchMemberDetails = async () => {
    try {
      console.log('Fetching member details for society:', society._id);
      const response = await axios.get(`http://localhost:5000/api/societies/${society._id}/members/details`);
      console.log('Member details response:', response.data);
      setMemberDetails(response.data || []);
    } catch (error) {
      console.error('Error fetching member details:', error);
      setMemberDetails([]);
    }
  };

  useEffect(() => {
    if (user) {
      fetchSocietyData();
      fetchPendingApplications();
      fetchVenues();
      fetchUpcomingAnnouncements();
      fetchEventReminders();
    }
  }, [user]);

  useEffect(() => {
    if (society) {
      console.log('Society data:', society);
      console.log('Current members:', society.members);
      fetchMemberDetails();
    }
  }, [society]);

  const handlePostSubmit = async (e) => {
    e.preventDefault();
    try {
      const formData = new FormData();
      formData.append('content', newPost.content);
      formData.append('isAnnouncement', newPost.isAnnouncement);
      if (selectedFile) {
        formData.append('file', selectedFile);
      }

      await axios.post(
        `http://localhost:5000/api/societies/${society._id}/posts`,
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        }
      );
      setNewPost({ content: '', isAnnouncement: false });
      setSelectedFile(null);
      fetchSocietyData();
    } catch (error) {
      alert('Error creating post: ' + error.message);
    }
  };

  const handleApplication = async (studentName, action) => {
    try {
      await axios.post(`http://localhost:5000/api/societies/${society._id}/applications/${studentName}/${action}`);
      fetchPendingApplications();
      fetchSocietyData();
    } catch (error) {
      alert(`Error ${action}ing application: ` + error.message);
    }
  };

  const handleDeleteComment = async (postIndex, commentIndex) => {
    try {
      await axios.delete(`http://localhost:5000/api/societies/${society._id}/posts/${postIndex}/comments/${commentIndex}`);
      fetchSocietyData();
    } catch (error) {
      alert('Error deleting comment: ' + error.message);
    }
  };

  const handleDeletePost = async (postIndex) => {
    if (!window.confirm('Are you sure you want to delete this post?')) {
      return;
    }

    try {
      await axios.delete(`http://localhost:5000/api/societies/${society._id}/posts/${postIndex}`);
      // Refresh society data after deletion
      fetchSocietyData();
    } catch (error) {
      alert('Error deleting post: ' + error.message);
    }
  };

  const handleAssignRole = async (member, role) => {
    try {
      await axios.post(`http://localhost:5000/api/societies/${society._id}/members/${member}/role`, { role });
      // Clear the role for this member after successful assignment
      setMemberRoles(prev => ({ ...prev, [member]: '' }));
      // Refresh society data
      fetchSocietyData();
    } catch (error) {
      alert(error.response?.data?.message || 'Error assigning role');
    }
  };

  const handleRemoveRole = async (memberName) => {
    try {
      await axios.delete(`http://localhost:5000/api/societies/${society._id}/members/${memberName}/role`);
      fetchSocietyData();
    } catch (error) {
      alert('Error removing role: ' + error.message);
    }
  };

  // Function to check if a role is already assigned
  const isRoleAssigned = (role) => {
    return society.memberRoles.some(r => r.role === role);
  };

  // Function to get the member who has a specific role
  const getMemberWithRole = (role) => {
    const roleData = society.memberRoles.find(r => r.role === role);
    return roleData ? roleData.memberName : null;
  };

  // Function to get a member's current role
  const getMemberRole = (memberName) => {
    const roleData = society.memberRoles.find(r => r.memberName === memberName);
    return roleData ? roleData.role : null;
  };

  const handleAddEvent = async (e) => {
    e.preventDefault();
    try {
      await axios.post(`http://localhost:5000/api/societies/${society._id}/events`, newEvent);
      setNewEvent({ name: '', description: '', date: '', startTime: '', endTime: '', venue: '' });
      fetchSocietyData();
    } catch (error) {
      alert(error.response?.data?.message || 'Error adding event');
    }
  };

  const handleScheduleAnnouncement = async (e) => {
    e.preventDefault();
    try {
      await axios.post(`http://localhost:5000/api/societies/${society._id}/announcements`, newAnnouncement);
      setNewAnnouncement({ content: '', scheduledFor: '' });
      fetchUpcomingAnnouncements();
      alert('Announcement scheduled successfully!');
    } catch (error) {
      alert('Error scheduling announcement: ' + error.message);
    }
  };

  const handleEditPost = async (postIndex, newContent) => {
    try {
      await axios.put(`http://localhost:5000/api/societies/${society._id}/posts/${postIndex}`, {
        content: newContent,
        editedBy: user.name
      });
      setEditingPost(null);
      fetchSocietyData();
    } catch (error) {
      alert('Error editing post: ' + error.message);
    }
  };

  const fetchMemberHistory = async (memberName) => {
    try {
      const response = await axios.get(`http://localhost:5000/api/societies/${society._id}/members/${memberName}/history`);
      setSelectedMemberHistory({
        memberName,
        history: response.data
      });
    } catch (error) {
      console.error('Error fetching member history:', error);
    }
  };

  const fetchApplicantHistory = async (studentName) => {
    try {
      const response = await axios.get(`http://localhost:5000/api/societies/${society._id}/members/${studentName}/history`);
      setSelectedApplicantHistory({
        studentName,
        history: response.data
      });
    } catch (error) {
      console.error('Error fetching applicant history:', error);
    }
  };

  const handleLeaveSociety = async () => {
    if (!window.confirm('Are you sure you want to leave this society? This action cannot be undone.')) {
      return;
    }

    try {
      await axios.post(`http://localhost:5000/api/societies/${society._id}/members/${user.name}/leave`);
      // Redirect to home page or show a message
      window.location.href = '/';
    } catch (error) {
      alert('Error leaving society: ' + error.message);
    }
  };

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        alert('File size must be less than 5MB');
        return;
      }
      setSelectedFile(file);
      setUploadingForPost(null);
    }
  };

  const handleFileUpload = async (postIndex) => {
    if (!selectedFile) return;

    setUploadingFile(true);
    const formData = new FormData();
    formData.append('file', selectedFile);

    try {
      await axios.post(
        `http://localhost:5000/api/societies/${society._id}/posts/${postIndex}/attachments`,
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        }
      );
      setSelectedFile(null);
      setUploadingForPost(null);
      fetchSocietyData();
    } catch (error) {
      alert('Error uploading file: ' + error.message);
    } finally {
      setUploadingFile(false);
    }
  };

  const handleDeleteAttachment = async (postIndex, attachmentIndex) => {
    if (!window.confirm('Are you sure you want to delete this attachment?')) {
      return;
    }

    try {
      await axios.delete(
        `http://localhost:5000/api/societies/${society._id}/posts/${postIndex}/attachments/${attachmentIndex}`
      );
      fetchSocietyData();
    } catch (error) {
      alert('Error deleting attachment: ' + error.message);
    }
  };

  if (!society) {
    return <div>Loading...</div>;
  }

  const isMember = society.members && society.members.includes(user.name);
  console.log('Debug info:', {
    user: user,
    society: society,
    isMember: isMember,
    members: society.members
  });

  return (
    <div className="dashboard fade-in">
      <Navbar userType="Society" user={user} onLogout={onLogout} />
      
      <div className="container">
        <div className="dashboard-header">
          <h2>{society.name} Dashboard</h2>
          <p>{society.description}</p>
          <p>Status: {society.isApproved ? 'Approved' : 'Pending Approval'}</p>
      </div>

        {/* Create Post Section */}
        <div className="card">
          <h3>Create New Post</h3>
          <form onSubmit={handlePostSubmit}>
            <div className="form-group">
              <label>Content:</label>
              <textarea
                value={newPost.content}
                onChange={(e) => setNewPost({ ...newPost, content: e.target.value })}
                required
                placeholder="Write your post content..."
                maxLength={1000}
              />
              <div className="char-count">
                {newPost.content.length}/1000 characters
            </div>
        </div>
            <div className="form-group">
              <label>
                <input
                  type="checkbox"
                  checked={newPost.isAnnouncement}
                  onChange={(e) => setNewPost({ ...newPost, isAnnouncement: e.target.checked })}
                />
                Mark as Announcement
              </label>
        </div>
            <div className="form-group">
              <label>Attachment (optional):</label>
              <input
                type="file"
                onChange={(e) => handleFileSelect(e)}
                accept=".pdf,.doc,.docx,.txt,.jpg,.jpeg,.png"
              />
            </div>
            <button type="submit" className="btn">Create Post</button>
          </form>
        </div>

      {/* Schedule Announcement Section */}
        <div className="card">
        <h3>Schedule Announcement</h3>
        <form onSubmit={handleScheduleAnnouncement}>
            <div className="form-group">
              <label>Content:</label>
            <textarea
              value={newAnnouncement.content}
              onChange={(e) => setNewAnnouncement({ ...newAnnouncement, content: e.target.value })}
              required
                placeholder="Write your announcement..."
                maxLength={1000}
            />
            <div className="char-count">
              {newAnnouncement.content.length}/1000 characters
            </div>
            </div>
            <div className="form-group">
              <label>Schedule For:</label>
            <input
              type="datetime-local"
              value={newAnnouncement.scheduledFor}
              onChange={(e) => setNewAnnouncement({ ...newAnnouncement, scheduledFor: e.target.value })}
              required
            />
          </div>
            <button type="submit" className="btn">Schedule Announcement</button>
        </form>
      </div>

        {/* Book Event Section */}
        <div className="card">
          <h3>Book New Event</h3>
          <form onSubmit={handleAddEvent}>
            <div className="form-group">
              <label>Event Name:</label>
              <input
                type="text"
                value={newEvent.name}
                onChange={(e) => setNewEvent({ ...newEvent, name: e.target.value })}
                required
                placeholder="Enter event name"
                maxLength={100}
              />
              <div className="char-count">
                {newEvent.name.length}/100 characters
              </div>
            </div>
            <div className="form-group">
              <label>Description:</label>
              <textarea
                value={newEvent.description}
                onChange={(e) => setNewEvent({ ...newEvent, description: e.target.value })}
                required
                placeholder="Describe your event"
                maxLength={500}
              />
              <div className="char-count">
                {newEvent.description.length}/500 characters
              </div>
            </div>
            <div className="form-group">
              <label>Date:</label>
              <input
                type="date"
                value={newEvent.date}
                onChange={(e) => setNewEvent({ ...newEvent, date: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>Start Time:</label>
              <input
                type="time"
                value={newEvent.startTime}
                onChange={(e) => setNewEvent({ ...newEvent, startTime: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>End Time:</label>
              <input
                type="time"
                value={newEvent.endTime}
                onChange={(e) => setNewEvent({ ...newEvent, endTime: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>Venue:</label>
              <select
                value={newEvent.venue}
                onChange={(e) => setNewEvent({ ...newEvent, venue: e.target.value })}
                required
                className="select-input"
              >
                <option value="">Select Venue</option>
                {venues.map((venue, index) => (
                  <option key={index} value={venue.name}>
                    {venue.name} (Capacity: {venue.capacity})
                  </option>
                ))}
              </select>
            </div>
            <button type="submit" className="btn">Book Event</button>
          </form>
        </div>

        {/* Event Reminders Section */}
        {eventReminders.length > 0 && (
          <div className="card">
            <h3>Event Reminders</h3>
            {eventReminders.map((event, index) => (
              <div key={index} className="event-reminder">
                <h4>{event.name}</h4>
                <p>{event.description}</p>
                <small>Date: {new Date(event.date).toLocaleDateString()}</small>
              </div>
            ))}
          </div>
        )}

      {/* Upcoming Announcements Section */}
      {upcomingAnnouncements.length > 0 && (
          <div className="card">
          <h3>Upcoming Announcements</h3>
          {upcomingAnnouncements.map((announcement, index) => (
              <div key={index} className="announcement">
              <p>{announcement.content}</p>
              <small>Scheduled for: {new Date(announcement.scheduledFor).toLocaleString()}</small>
            </div>
          ))}
        </div>
      )}

      {/* Pending Applications Section */}
      {pendingApplications.length > 0 && (
          <div className="card">
          <h3>Pending Applications</h3>
            <div className="grid">
            {pendingApplications.map((application, index) => (
                <div key={index} className="application-card">
                  <div className="application-header">
                    <h4>{application.studentName}</h4>
                  <button 
                    onClick={() => fetchApplicantHistory(application.studentName)}
                      className="btn"
                  >
                    View History
                  </button>
                </div>
                  <div className="btn-group">
                  <button 
                    onClick={() => handleApplication(application.studentName, 'approve')}
                      className="btn btn-success"
                  >
                    Approve
                  </button>
                  <button 
                    onClick={() => handleApplication(application.studentName, 'reject')}
                      className="btn btn-error"
                  >
                    Reject
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Posts Section */}
        <div className="card">
        <h3>Posts</h3>
        {society.posts && society.posts.length > 0 ? (
            <div className="posts-grid">
              {society.posts.map((post, index) => (
                <div key={index} className="post-card">
              <div className="post-header">
                <h4>{post.isAnnouncement ? '📢 Announcement' : 'Post'}</h4>
                    <div className="btn-group">
                  <button 
                        className="btn"
                    onClick={() => setEditingPost({ index, content: post.content })}
                  >
                    Edit
                  </button>
                  <button 
                        className="btn btn-error"
                    onClick={() => handleDeletePost(index)}
                  >
                    Delete
                  </button>
                </div>
              </div>
              {editingPost && editingPost.index === index ? (
                <div className="edit-post-form">
                  <textarea
                    value={editingPost.content}
                    onChange={(e) => setEditingPost({ ...editingPost, content: e.target.value })}
                    maxLength={1000}
                  />
                  <div className="char-count">
                    {editingPost.content.length}/1000 characters
                  </div>
                  <div className="btn-group">
                    <button 
                      className="btn btn-success"
                      onClick={() => handleEditPost(index, editingPost.content)}
                    >
                      Save
                    </button>
                    <button 
                      className="btn btn-error"
                      onClick={() => setEditingPost(null)}
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                  <p>{post.content}</p>
              )}
                  <div className="comments-section">
                <h5>Comments</h5>
                {post.comments && post.comments.length > 0 ? (
                  post.comments.map((comment, commentIndex) => (
                        <div key={commentIndex} className="comment-card">
                      <strong>{comment.author}:</strong> {comment.content}
                      <button 
                            className="btn btn-small btn-error"
                        onClick={() => handleDeleteComment(index, commentIndex)}
                      >
                        Delete
                      </button>
                    </div>
                  ))
                ) : (
                  <p>No comments yet</p>
                )}
              </div>
            </div>
              ))}
            </div>
        ) : (
          <p>No posts yet</p>
        )}
      </div>

        {/* Members Section */}
        <div className="card">
        <h3>Members ({society.members.length})</h3>
          {console.log('Current memberDetails state:', memberDetails)}
          <div className="grid">
          {society.members.map((member, index) => {
            const currentRole = getMemberRole(member);
            const memberDetail = memberDetails.find(m => m.name === member);
            console.log('Rendering member card:', {
              member,
              memberDetail,
              hasRollNumber: memberDetail?.rollNumber,
              allMemberDetails: memberDetails
            });
            return (
                <div key={index} className="member-card">
                <div className="member-info">
                  <p><strong>{member}</strong></p>
                  {memberDetail?.rollNumber ? (
                    <p className="roll-number">Roll Number: {memberDetail.rollNumber}</p>
                  ) : (
                    <p className="roll-number">Roll Number: Not found</p>
                  )}
                </div>
                {currentRole ? (
                  <div>
                    <p>Role: {currentRole}</p>
                    <button 
                      onClick={() => handleRemoveRole(member)}
                        className="btn btn-error"
                    >
                      Remove Role
                    </button>
                  </div>
                ) : (
                  <div>
                    <select 
                      value={memberRoles[member] || ''} 
                      onChange={(e) => setMemberRoles(prev => ({ ...prev, [member]: e.target.value }))}
                        className="select-input"
                    >
                      <option value="">Select Role</option>
                      {['President', 'Vice President', 'Secretary', 'Treasurer', 'Event Coordinator'].map(role => (
                        <option 
                          key={role} 
                          value={role}
                          disabled={isRoleAssigned(role) && getMemberWithRole(role) !== member}
                        >
                          {role} {isRoleAssigned(role) && getMemberWithRole(role) !== member ? `(Assigned to ${getMemberWithRole(role)})` : ''}
                        </option>
                      ))}
                    </select>
                    <button 
                      onClick={() => handleAssignRole(member, memberRoles[member])}
                      disabled={!memberRoles[member]}
                        className="btn btn-success"
                    >
                      Assign Role
                    </button>
                  </div>
                )}
                <button 
                  onClick={() => fetchMemberHistory(member)}
                    className="btn"
                >
                  View History
                </button>
              </div>
            );
          })}
          </div>
        </div>

        {/* Events Section */}
        <div className="card">
          <h3>Society Events</h3>
          {society?.events && society.events.length > 0 ? (
            <div className="grid">
              {society.events.map((event, index) => (
                <div key={index} className="event-card">
                  <h4>{event.name}</h4>
                  <p>{event.description}</p>
                  <p>Date: {new Date(event.date).toLocaleDateString()}</p>
                  <p>Time: {event.startTime} - {event.endTime}</p>
                  <p>Venue: {event.venue}</p>
                  <p className={`badge ${
                    event.status === 'approved' ? 'badge-success' :
                    event.status === 'rejected' ? 'badge-error' :
                    'badge-warning'
                  }`}>
                    Status: {event.status.charAt(0).toUpperCase() + event.status.slice(1)}
                  </p>
                  {event.comments && event.comments.length > 0 && (
                    <div className="comments-section">
                      <h5>Comments</h5>
                      {event.comments.map((comment, commentIndex) => (
                        <div key={commentIndex} className="comment">
                          <strong>{comment.author}:</strong> {comment.content}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <p>No events yet</p>
          )}
        </div>
      </div>

      {/* Modals */}
        {selectedMemberHistory && (
        <div className="modal">
          <div className="modal-content card">
              <h3>{selectedMemberHistory.memberName}'s History</h3>
            <div className="history-list">
                {selectedMemberHistory.history.map((entry, index) => (
                <div key={index} className="history-item">
                    <p><strong>Action:</strong> {entry.action.replace('_', ' ').toUpperCase()}</p>
                    <p><strong>Details:</strong> {entry.details}</p>
                    <small>{new Date(entry.timestamp).toLocaleString()}</small>
                  </div>
                ))}
              </div>
              <button 
                onClick={() => setSelectedMemberHistory(null)}
              className="btn"
              >
                Close
              </button>
            </div>
          </div>
        )}

      {selectedApplicantHistory && (
        <div className="modal">
          <div className="modal-content card">
            <h3>{selectedApplicantHistory.studentName}'s History</h3>
            <div className="history-list">
              {selectedApplicantHistory.history.map((entry, index) => (
                <div key={index} className="history-item">
                  <p><strong>Action:</strong> {entry.action.replace('_', ' ').toUpperCase()}</p>
                  <p><strong>Details:</strong> {entry.details}</p>
                  <small>{new Date(entry.timestamp).toLocaleString()}</small>
                </div>
              ))}
          </div>
            <button 
              onClick={() => setSelectedApplicantHistory(null)}
              className="btn"
            >
              Close
            </button>
                      </div>
                </div>
          )}
    </div>
  );
}

export default SocietyDashboard;

<style>
{`
  .post-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
  }

  .edit-button {
    background: #17a2b8;
    color: white;
    border: none;
    padding: 5px 10px;
    border-radius: 4px;
    cursor: pointer;
    margin-right: 10px;
  }

  .edit-button:hover {
    background: #138496;
  }

  .delete-button {
    background: #dc3545;
    color: white;
    border: none;
    padding: 5px 10px;
    border-radius: 4px;
    cursor: pointer;
  }

  .delete-button:hover {
    background: #c82333;
  }

  .delete-comment-button {
    background: #dc3545;
    color: white;
    border: none;
    padding: 3px 8px;
    border-radius: 4px;
    cursor: pointer;
    margin-left: 10px;
    font-size: 0.8em;
  }

  .delete-comment-button:hover {
    background: #c82333;
  }

  .edit-post-form {
    margin: 10px 0;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 4px;
  }

  .char-count {
    font-size: 0.8rem;
    color: var(--text-gray);
    text-align: right;
    margin-top: 0.25rem;
  }
`}
</style> 