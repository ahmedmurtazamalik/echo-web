import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Navbar from './Navbar';
import '../styles/global.css';

function SocietyEvents({ user, onLogout }) {
  const [society, setSociety] = useState(null);
  const [venues, setVenues] = useState([]);
  const [newEvent, setNewEvent] = useState({
    name: '',
    description: '',
    date: '',
    startTime: '',
    endTime: '',
    venue: ''
  });

  const fetchSocietyData = async () => {
    try {
      const response = await axios.get(`http://localhost:5000/api/societies/${user.name}`);
      setSociety(response.data);
    } catch (error) {
      console.error('Error fetching society data:', error);
    }
  };

  const fetchVenues = async () => {
    try {
      const response = await axios.get(`http://localhost:5000/api/admin/venues`);
      setVenues(response.data);
    } catch (error) {
      console.error('Error fetching venues:', error);
    }
  };

  useEffect(() => {
    if (user) {
      fetchSocietyData();
      fetchVenues();
    }
  }, [user]);

  const handleAddEvent = async (e) => {
    e.preventDefault();
    try {
      await axios.post(`http://localhost:5000/api/societies/${society._id}/events`, newEvent);
      setNewEvent({ name: '', description: '', date: '', startTime: '', endTime: '', venue: '' });
      fetchSocietyData();
      alert('Event created successfully! Waiting for admin approval.');
    } catch (error) {
      alert(error.response?.data?.message || 'Error adding event');
    }
  };

  if (!society) {
    return <div>Loading...</div>;
  }

  return (
    <div className="dashboard fade-in">
      <Navbar userType="Society" user={user} onLogout={onLogout} />
      
      <div className="container">
        <div className="card">
          <h3>Book New Event</h3>
          <form onSubmit={handleAddEvent}>
            <div className="form-group">
              <label>Event Name:</label>
              <input
                type="text"
                value={newEvent.name}
                onChange={(e) => setNewEvent({ ...newEvent, name: e.target.value })}
                required
                placeholder="Enter event name"
              />
            </div>
            <div className="form-group">
              <label>Description:</label>
              <textarea
                value={newEvent.description}
                onChange={(e) => setNewEvent({ ...newEvent, description: e.target.value })}
                required
                placeholder="Describe your event"
              />
            </div>
            <div className="form-group">
              <label>Date:</label>
              <input
                type="date"
                value={newEvent.date}
                onChange={(e) => setNewEvent({ ...newEvent, date: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>Start Time:</label>
              <input
                type="time"
                value={newEvent.startTime}
                onChange={(e) => setNewEvent({ ...newEvent, startTime: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>End Time:</label>
              <input
                type="time"
                value={newEvent.endTime}
                onChange={(e) => setNewEvent({ ...newEvent, endTime: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>Venue:</label>
              <select
                value={newEvent.venue}
                onChange={(e) => setNewEvent({ ...newEvent, venue: e.target.value })}
                required
                className="select-input"
              >
                <option value="">Select Venue</option>
                {venues.map((venue, index) => (
                  <option key={index} value={venue.name}>
                    {venue.name} (Capacity: {venue.capacity})
                  </option>
                ))}
              </select>
            </div>
            <button type="submit" className="btn">Book Event</button>
          </form>
        </div>

        <div className="card">
          <h3>Society Events</h3>
          {society.events && society.events.length > 0 ? (
            <div className="grid">
              {society.events.map((event, index) => (
                <div key={index} className="event-card">
                  <h4>{event.name}</h4>
                  <p>{event.description}</p>
                  <p>Date: {new Date(event.date).toLocaleDateString()}</p>
                  <p>Time: {event.startTime} - {event.endTime}</p>
                  <p>Venue: {event.venue}</p>
                  <p className={`badge ${
                    event.status === 'approved' ? 'badge-success' :
                    event.status === 'rejected' ? 'badge-error' :
                    'badge-warning'
                  }`}>
                    Status: {event.status.charAt(0).toUpperCase() + event.status.slice(1)}
                  </p>
                  {event.comments && event.comments.length > 0 && (
                    <div className="comments-section">
                      <h5>Comments</h5>
                      {event.comments.map((comment, commentIndex) => (
                        <div key={commentIndex} className="comment">
                          <strong>{comment.author}:</strong> {comment.content}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <p>No events yet</p>
          )}
        </div>
      </div>
    </div>
  );
}

export default SocietyEvents; 