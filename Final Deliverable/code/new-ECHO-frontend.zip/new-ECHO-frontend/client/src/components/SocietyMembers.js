import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Navbar from './Navbar';
import '../styles/global.css';

function SocietyMembers({ user, onLogout }) {
  const [society, setSociety] = useState(null);
  const [pendingApplications, setPendingApplications] = useState([]);
  const [selectedMember, setSelectedMember] = useState(null);
  const [memberRoles, setMemberRoles] = useState({});
  const [selectedMemberHistory, setSelectedMemberHistory] = useState(null);
  const [selectedApplicantHistory, setSelectedApplicantHistory] = useState(null);

  const fetchSocietyData = async () => {
    try {
      const response = await axios.get(`http://localhost:5000/api/societies/${user.name}`);
      setSociety(response.data);
    } catch (error) {
      console.error('Error fetching society data:', error);
    }
  };

  const fetchPendingApplications = async () => {
    try {
      const response = await axios.get(`http://localhost:5000/api/societies/${user.name}/applications`);
      setPendingApplications(response.data);
    } catch (error) {
      console.error('Error fetching applications:', error);
    }
  };

  useEffect(() => {
    if (user) {
      fetchSocietyData();
      fetchPendingApplications();
    }
  }, [user]);

  const handleApplication = async (studentName, action) => {
    try {
      await axios.post(`http://localhost:5000/api/societies/${society._id}/applications/${studentName}/${action}`);
      
      // First update the local state to remove the application
      setPendingApplications(prevApplications => 
        prevApplications.filter(app => app.studentName !== studentName)
      );
      
      // Then fetch fresh data
      await fetchSocietyData();
      await fetchPendingApplications();
    } catch (error) {
      alert(`Error ${action}ing application: ` + error.message);
    }
  };

  const handleAssignRole = async (member, role) => {
    try {
      await axios.post(`http://localhost:5000/api/societies/${society._id}/members/${member}/role`, { role });
      setMemberRoles(prev => ({ ...prev, [member]: '' }));
      fetchSocietyData();
    } catch (error) {
      alert(error.response?.data?.message || 'Error assigning role');
    }
  };

  const handleRemoveRole = async (memberName) => {
    try {
      await axios.delete(`http://localhost:5000/api/societies/${society._id}/members/${memberName}/role`);
      fetchSocietyData();
    } catch (error) {
      alert('Error removing role: ' + error.message);
    }
  };

  const fetchMemberHistory = async (memberName) => {
    try {
      const response = await axios.get(`http://localhost:5000/api/societies/${society._id}/members/${memberName}/history`);
      setSelectedMemberHistory({
        memberName,
        history: response.data
      });
    } catch (error) {
      console.error('Error fetching member history:', error);
    }
  };

  const fetchApplicantHistory = async (studentName) => {
    try {
      const response = await axios.get(`http://localhost:5000/api/societies/${society._id}/members/${studentName}/history`);
      setSelectedApplicantHistory({
        studentName,
        history: response.data
      });
    } catch (error) {
      console.error('Error fetching applicant history:', error);
    }
  };

  // Function to check if a role is already assigned
  const isRoleAssigned = (role) => {
    return society.memberRoles.some(r => r.role === role);
  };

  // Function to get the member who has a specific role
  const getMemberWithRole = (role) => {
    const roleData = society.memberRoles.find(r => r.role === role);
    return roleData ? roleData.memberName : null;
  };

  // Function to get a member's current role
  const getMemberRole = (memberName) => {
    const roleData = society.memberRoles.find(r => r.memberName === memberName);
    return roleData ? roleData.role : null;
  };

  if (!society) {
    return <div>Loading...</div>;
  }

  return (
    <div className="dashboard fade-in">
      <Navbar userType="Society" user={user} onLogout={onLogout} />
      
      <div className="container">
        {/* Pending Applications Section */}
        {pendingApplications.length > 0 && (
          <div className="card">
            <h3>Pending Applications</h3>
            <div className="grid">
              {pendingApplications.map((application, index) => (
                <div key={index} className="application-card">
                  <div className="application-header">
                    <h4>{application.studentName}</h4>
                    <button 
                      onClick={() => fetchApplicantHistory(application.studentName)}
                      className="btn"
                    >
                      View History
                    </button>
                  </div>
                  <div className="btn-group">
                    <button 
                      onClick={() => handleApplication(application.studentName, 'approve')}
                      className="btn btn-success"
                    >
                      Approve
                    </button>
                    <button 
                      onClick={() => handleApplication(application.studentName, 'reject')}
                      className="btn btn-error"
                    >
                      Reject
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Members Section */}
        <div className="card">
          <h3>Members ({society.members.length})</h3>
          <div className="grid">
            {society.members.map((member, index) => {
              const currentRole = getMemberRole(member);
              return (
                <div key={index} className="member-card">
                  <p><strong>{member}</strong></p>
                  {currentRole ? (
                    <div>
                      <p>Role: {currentRole}</p>
                      <button 
                        onClick={() => handleRemoveRole(member)}
                        className="btn btn-error"
                      >
                        Remove Role
                      </button>
                    </div>
                  ) : (
                    <div>
                      <select 
                        value={memberRoles[member] || ''} 
                        onChange={(e) => setMemberRoles(prev => ({ ...prev, [member]: e.target.value }))}
                        className="select-input"
                      >
                        <option value="">Select Role</option>
                        {['President', 'Vice President', 'Secretary', 'Treasurer', 'Event Coordinator'].map(role => (
                          <option 
                            key={role} 
                            value={role}
                            disabled={isRoleAssigned(role) && getMemberWithRole(role) !== member}
                          >
                            {role} {isRoleAssigned(role) && getMemberWithRole(role) !== member ? `(Assigned to ${getMemberWithRole(role)})` : ''}
                          </option>
                        ))}
                      </select>
                      <button 
                        onClick={() => handleAssignRole(member, memberRoles[member])}
                        disabled={!memberRoles[member]}
                        className="btn btn-success"
                      >
                        Assign Role
                      </button>
                    </div>
                  )}
                  <button 
                    onClick={() => fetchMemberHistory(member)}
                    className="btn"
                  >
                    View History
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Modals */}
      {selectedMemberHistory && (
        <div className="modal">
          <div className="modal-content card">
            <h3>{selectedMemberHistory.memberName}'s History</h3>
            <div className="history-list">
              {selectedMemberHistory.history.map((entry, index) => (
                <div key={index} className="history-item">
                  <p><strong>Action:</strong> {entry.action.replace('_', ' ').toUpperCase()}</p>
                  <p><strong>Details:</strong> {entry.details}</p>
                  <small>{new Date(entry.timestamp).toLocaleString()}</small>
                </div>
              ))}
            </div>
            <button 
              onClick={() => setSelectedMemberHistory(null)}
              className="btn"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {selectedApplicantHistory && (
        <div className="modal">
          <div className="modal-content card">
            <h3>{selectedApplicantHistory.studentName}'s History</h3>
            <div className="history-list">
              {selectedApplicantHistory.history.map((entry, index) => (
                <div key={index} className="history-item">
                  <p><strong>Action:</strong> {entry.action.replace('_', ' ').toUpperCase()}</p>
                  <p><strong>Details:</strong> {entry.details}</p>
                  <small>{new Date(entry.timestamp).toLocaleString()}</small>
                </div>
              ))}
            </div>
            <button 
              onClick={() => setSelectedApplicantHistory(null)}
              className="btn"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default SocietyMembers; 