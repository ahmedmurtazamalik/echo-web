import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Navbar from './Navbar';
import '../styles/global.css';

function SocietyPosts({ user, onLogout }) {
  const [society, setSociety] = useState(null);
  const [newPost, setNewPost] = useState({ content: '', isAnnouncement: false });
  const [editingPost, setEditingPost] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [filePreview, setFilePreview] = useState(null);

  const ACCEPTED_FILE_TYPES = '.pdf,.doc,.docx,.txt,.jpg,.jpeg,.png,.xlsx,.xls';
  const IMAGE_FILE_TYPES = ['image/jpeg', 'image/png', 'image/jpg'];

  const fetchSocietyData = async () => {
    try {
      const response = await axios.get(`http://localhost:5000/api/societies/${user.name}`);
      setSociety(response.data);
    } catch (error) {
      console.error('Error fetching society data:', error);
    }
  };

  useEffect(() => {
    if (user) {
      fetchSocietyData();
    }
  }, [user]);

  const handlePostSubmit = async (e) => {
    e.preventDefault();
    try {
      const formData = new FormData();
      formData.append('content', newPost.content);
      formData.append('isAnnouncement', newPost.isAnnouncement);
      if (selectedFile) {
        formData.append('file', selectedFile);
      }

      await axios.post(
        `http://localhost:5000/api/societies/${society._id}/posts`,
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        }
      );
      setNewPost({ content: '', isAnnouncement: false });
      setSelectedFile(null);
      setFilePreview(null);
      fetchSocietyData();
    } catch (error) {
      alert('Error creating post: ' + error.message);
    }
  };

  const handleEditPost = async (postIndex, newContent) => {
    try {
      await axios.put(`http://localhost:5000/api/societies/${society._id}/posts/${postIndex}`, {
        content: newContent,
        editedBy: user.name
      });
      setEditingPost(null);
      fetchSocietyData();
    } catch (error) {
      alert('Error editing post: ' + error.message);
    }
  };

  const handleDeletePost = async (postIndex) => {
    if (!window.confirm('Are you sure you want to delete this post?')) {
      return;
    }

    try {
      await axios.delete(`http://localhost:5000/api/societies/${society._id}/posts/${postIndex}`);
      fetchSocietyData();
    } catch (error) {
      alert('Error deleting post: ' + error.message);
    }
  };

  const handleDeleteComment = async (postIndex, commentIndex) => {
    try {
      await axios.delete(`http://localhost:5000/api/societies/${society._id}/posts/${postIndex}/comments/${commentIndex}`);
      fetchSocietyData();
    } catch (error) {
      alert('Error deleting comment: ' + error.message);
    }
  };

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        alert('File size must be less than 5MB');
        return;
      }
      setSelectedFile(file);

      // Create preview for images
      if (IMAGE_FILE_TYPES.includes(file.type)) {
        const reader = new FileReader();
        reader.onloadend = () => {
          setFilePreview(reader.result);
        };
        reader.readAsDataURL(file);
      } else {
        setFilePreview(null);
      }
    }
  };

  const getFileIcon = (fileType) => {
    if (fileType.includes('pdf')) return '📄';
    if (fileType.includes('doc')) return '📝';
    if (fileType.includes('sheet') || fileType.includes('xlsx') || fileType.includes('xls')) return '📊';
    if (fileType.includes('text')) return '📃';
    return '📎';
  };

  if (!society) {
    return <div>Loading...</div>;
  }

  return (
    <div className="dashboard fade-in">
      <Navbar userType="Society" user={user} onLogout={onLogout} />
      
      <div className="container">
        <div className="card">
          <h3>Create New Post</h3>
          <form onSubmit={handlePostSubmit}>
            <div className="form-group">
              <label>Content:</label>
              <textarea
                value={newPost.content}
                onChange={(e) => setNewPost({ ...newPost, content: e.target.value })}
                required
                placeholder="Write your post content..."
                maxLength={1000}
              />
              <div className="char-count">
                {newPost.content.length}/1000 characters
              </div>
            </div>
            <div className="form-group">
              <label>
                <input
                  type="checkbox"
                  checked={newPost.isAnnouncement}
                  onChange={(e) => setNewPost({ ...newPost, isAnnouncement: e.target.checked })}
                />
                Mark as Announcement
              </label>
            </div>
            <div className="form-group">
              <label>Attachment (optional):</label>
              <input
                type="file"
                onChange={handleFileSelect}
                accept={ACCEPTED_FILE_TYPES}
              />
              {filePreview && (
                <div className="file-preview">
                  <img src={filePreview} alt="File preview" />
                </div>
              )}
              {selectedFile && !filePreview && (
                <div className="file-info">
                  {getFileIcon(selectedFile.type)} {selectedFile.name}
                </div>
              )}
            </div>
            <button type="submit" className="btn">Create Post</button>
          </form>
        </div>

        <div className="card">
          <h3>Posts</h3>
          {society.posts && society.posts.length > 0 ? (
            <div className="posts-grid">
              {society.posts.map((post, index) => (
                <div key={index} className="post-card">
                  <div className="post-header">
                    <h4>{post.isAnnouncement ? '📢 Announcement' : 'Post'}</h4>
                    <div className="btn-group">
                      <button 
                        className="btn"
                        onClick={() => setEditingPost({ index, content: post.content })}
                      >
                        Edit
                      </button>
                      <button 
                        className="btn btn-error"
                        onClick={() => handleDeletePost(index)}
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                  {editingPost?.index === index ? (
                    <div className="edit-post-form">
                      <textarea
                        value={editingPost.content}
                        onChange={(e) => setEditingPost({ ...editingPost, content: e.target.value })}
                        maxLength={1000}
                      />
                      <div className="char-count">
                        {editingPost.content.length}/1000 characters
                      </div>
                      <div className="btn-group">
                        <button 
                          className="btn btn-success"
                          onClick={() => handleEditPost(index, editingPost.content)}
                        >
                          Save
                        </button>
                        <button 
                          className="btn btn-error"
                          onClick={() => setEditingPost(null)}
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <>
                      <p>{post.content}</p>
                      <small className="post-timestamp">Posted on: {new Date(post.createdAt).toLocaleString()}</small>
                    </>
                  )}
                  {post.attachments && post.attachments.length > 0 && (
                    <div className="attachments-section">
                      <h5>Attachments</h5>
                      {post.attachments.map((attachment, attachmentIndex) => (
                        <div key={attachmentIndex} className="attachment">
                          {attachment.fileType && attachment.fileType.startsWith('image/') ? (
                            <img 
                              src={attachment.fileUrl} 
                              alt={attachment.fileName} 
                              className="post-image"
                            />
                          ) : (
                            <a href={attachment.fileUrl} target="_blank" rel="noopener noreferrer">
                              {getFileIcon(attachment.fileType)} {attachment.fileName}
                            </a>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                  <div className="comments-section">
                    <h5>Comments</h5>
                    {post.comments && post.comments.length > 0 ? (
                      post.comments.map((comment, commentIndex) => (
                        <div key={commentIndex} className="comment-card">
                          <div className="comment-content">
                            <strong>{comment.author}:</strong> {comment.content}
                            <small className="comment-timestamp">
                              {new Date(comment.createdAt).toLocaleString()}
                            </small>
                          </div>
                          {comment.author === user.name && (
                            <button 
                              className="delete-comment-btn"
                              onClick={() => handleDeleteComment(index, commentIndex)}
                              title="Delete comment"
                            >
                              ×
                            </button>
                          )}
                        </div>
                      ))
                    ) : (
                      <p>No comments yet</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p>No posts yet</p>
          )}
        </div>
      </div>

      <style jsx>{`
        .char-count {
          font-size: 0.8rem;
          color: var(--text-gray);
          text-align: right;
          margin-top: 0.25rem;
        }

        .file-preview {
          margin-top: 1rem;
          width: 200px;
          height: 200px;
          overflow: hidden;
          border-radius: 4px;
          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .file-preview img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          border-radius: 4px;
        }

        .file-info {
          margin-top: 0.5rem;
          padding: 0.5rem;
          background: var(--bg-secondary);
          border-radius: 4px;
          display: inline-block;
        }

        .image-attachment {
          margin: 1rem 0;
          width: 300px;
          height: 300px;
          overflow: hidden;
          border-radius: 4px;
          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
          cursor: pointer;
          transition: transform 0.2s ease;
        }

        .image-attachment:hover {
          transform: scale(1.02);
        }

        .image-attachment img {
          width: 100%;
          height: 100%;
          object-fit: cover;
          border-radius: 4px;
        }

        .attachment {
          margin: 0.5rem 0;
        }

        .attachment a {
          display: inline-flex;
          align-items: center;
          gap: 0.5rem;
          color: var(--accent-blue);
          text-decoration: none;
          padding: 0.5rem;
          background: var(--bg-secondary);
          border-radius: 4px;
        }

        .attachment a:hover {
          background: var(--bg-hover);
        }

        .post-timestamp {
          color: var(--text-gray);
          display: block;
          margin-top: 0.5rem;
          font-size: 0.85rem;
        }

        .comment-card {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          padding: 0.5rem;
          margin: 0.5rem 0;
          background: var(--bg-secondary);
          border-radius: 4px;
        }

        .comment-content {
          flex-grow: 1;
        }

        .comment-timestamp {
          display: block;
          color: var(--text-gray);
          font-size: 0.75rem;
          margin-top: 0.25rem;
        }

        .delete-comment-btn {
          background: none;
          border: none;
          color: var(--text-gray);
          font-size: 1.2rem;
          cursor: pointer;
          padding: 0 0.5rem;
          opacity: 0.6;
          transition: opacity var(--transition-speed), color var(--transition-speed);
        }

        .delete-comment-btn:hover {
          opacity: 1;
          color: var(--accent-blue);
        }
      `}</style>
    </div>
  );
}

export default SocietyPosts; 