import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Navbar from './Navbar';
import '../styles/global.css';

function SocietyProfile({ user, onLogout }) {
  const [society, setSociety] = useState(null);
  const [editMode, setEditMode] = useState(false);
  const [formData, setFormData] = useState({
    description: '',
    category: ''
  });

  useEffect(() => {
    fetchSocietyData();
  }, [user.name]);

  const fetchSocietyData = async () => {
    try {
      const response = await axios.get(`http://localhost:5000/api/societies/${user.name}`);
      setSociety(response.data);
      setFormData({
        description: response.data.description,
        category: response.data.category
      });
    } catch (error) {
      console.error('Error fetching society data:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`http://localhost:5000/api/societies/${society._id}/profile`, formData);
      fetchSocietyData();
      setEditMode(false);
    } catch (error) {
      console.error('Error updating profile:', error);
    }
  };

  if (!society) {
    return <div>Loading...</div>;
  }

  return (
    <div className="dashboard fade-in">
      <Navbar userType="Society" user={user} onLogout={onLogout} />
      
      <div className="container">
        <div className="card">
          <h2>{society.name}'s Profile</h2>
          {editMode ? (
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label>Description:</label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>Category:</label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  required
                  className="select-input"
                >
                  <option value="">Select Category</option>
                  <option value="Academic">Academic</option>
                  <option value="Sports">Sports</option>
                  <option value="Cultural">Cultural</option>
                  <option value="Technical">Technical</option>
                  <option value="Social">Social</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              <div className="btn-group">
                <button type="submit" className="btn btn-success">Save Changes</button>
                <button type="button" className="btn btn-error" onClick={() => setEditMode(false)}>Cancel</button>
              </div>
            </form>
          ) : (
            <div>
              <p><strong>Description:</strong> {society.description}</p>
              <p><strong>Category:</strong> {society.category}</p>
              <p><strong>Status:</strong> {society.isApproved ? 'Approved' : 'Pending Approval'}</p>
              <p><strong>Total Members:</strong> {society.members.length}</p>
              <button className="btn" onClick={() => setEditMode(true)}>Edit Profile</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default SocietyProfile; 