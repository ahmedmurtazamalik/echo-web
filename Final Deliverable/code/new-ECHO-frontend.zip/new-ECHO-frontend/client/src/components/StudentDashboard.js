import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useLocation } from 'react-router-dom';
import StudentProfile from './StudentProfile';
import Navbar from './Navbar';
import '../styles/global.css';

function StudentDashboard({ user, onLogout }) {
  const [societies, setSocieties] = useState([]);
  const [applications, setApplications] = useState([]);
  const [selectedSociety, setSelectedSociety] = useState(null);
  const [newComment, setNewComment] = useState({});
  const location = useLocation();
  const [viewMode, setViewMode] = useState(
    location.state?.activeView || 'societies'
  );

  useEffect(() => {
    if (location.state?.activeView) {
      setViewMode(location.state.activeView);
    }
  }, [location.state]);

  useEffect(() => {
    fetchSocieties();
    fetchMyApplications();
  }, []);

  const fetchSocieties = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/societies/available');
      setSocieties(response.data);
    } catch (error) {
      alert('Error fetching societies: ' + error.message);
    }
  };

  const fetchMyApplications = async () => {
    try {
      const response = await axios.get(`http://localhost:5000/api/students/${user.name}/applications`);
      setApplications(response.data);
    } catch (error) {
      alert('Error fetching applications: ' + error.message);
    }
  };

  const handleApply = async (societyId) => {
    try {
      await axios.post(`http://localhost:5000/api/students/${user.name}/applications`, {
        societyId
      });
      fetchMyApplications();
      alert('Application submitted successfully!');
    } catch (error) {
      alert('Error submitting application: ' + error.message);
    }
  };

  const handleViewSociety = (society) => {
    setSelectedSociety(society);
    setViewMode('society-details');
  };

  const handleBackToSocieties = () => {
    setSelectedSociety(null);
    setViewMode('societies');
  };

  const handleComment = async (societyId, postIndex) => {
    try {
      if (!newComment[postIndex]?.trim()) {
        alert('Please enter a comment');
        return;
      }

      await axios.post(`http://localhost:5000/api/students/${user.name}/posts/${societyId}/${postIndex}/comments`, {
        content: newComment[postIndex]
      });

      // Clear the comment input
      setNewComment(prev => ({ ...prev, [postIndex]: '' }));

      // Refresh the society data to show the new comment
      const response = await axios.get(`http://localhost:5000/api/societies/${selectedSociety.name}`);
      setSelectedSociety(response.data);
    } catch (error) {
      alert('Error posting comment: ' + error.message);
    }
  };

  const getApplicationStatus = (societyName) => {
    const application = applications.find(app => app.societyName === societyName);
    if (!application) return null;
    return application.status;
  };

  const isMember = (societyName) => {
    const application = applications.find(app => app.societyName === societyName);
    return application?.status === 'accepted';
  };

  const hasApplied = (society) => {
    const application = applications.find(app => app.societyName === society.name);
    return application !== undefined;
  };

  const getMemberRole = (society, memberName) => {
    if (!society.memberRoles) return null;
    const roleData = society.memberRoles.find(r => r.memberName === memberName);
    return roleData ? roleData.role : null;
  };

  const handleLeaveSociety = async (societyId) => {
    if (!window.confirm('Are you sure you want to leave this society? This action cannot be undone.')) {
      return;
    }

    try {
      await axios.post(`http://localhost:5000/api/societies/${societyId}/members/${user.name}/leave`);
      
      // Update applications state by removing the application for this society
      setApplications(prevApplications => 
        prevApplications.filter(app => app.societyName !== selectedSociety.name)
      );
      
      // Update societies state by removing the user from the members list
      setSocieties(prevSocieties => 
        prevSocieties.map(society => {
          if (society._id === societyId) {
            return {
              ...society,
              members: society.members.filter(member => member !== user.name),
              memberRoles: society.memberRoles.filter(r => r.memberName !== user.name)
            };
          }
          return society;
        })
      );

      // Go back to societies view
      handleBackToSocieties();
    } catch (error) {
      alert('Error leaving society: ' + error.message);
    }
  };

  return (
    <div className="dashboard fade-in">
      <Navbar userType="Student" user={user} onLogout={onLogout} />
      
      <div className="container">
        <h2>Welcome, {user.name}</h2>
        {viewMode === 'profile' ? (
          <StudentProfile user={user} />
        ) : viewMode === 'society-details' && selectedSociety ? (
          <div className="society-details-view">
            <button onClick={handleBackToSocieties} className="btn btn-back">
              ← Back to Societies
            </button>
          
            <div className="card">
              <h2>{selectedSociety.name}</h2>
              <div className="society-info">
              <p><strong>Description:</strong> {selectedSociety.description}</p>
              <p><strong>Category:</strong> {selectedSociety.category}</p>
              <p><strong>Members:</strong> {selectedSociety.members.length}</p>
              {isMember(selectedSociety.name) && (
                <p><strong>Your Role:</strong> {getMemberRole(selectedSociety, user.name) || 'Member'}</p>
              )}
                {isMember(selectedSociety.name) && (
                  <button onClick={() => handleLeaveSociety(selectedSociety._id)} className="btn btn-error">
                    Leave Society
                  </button>
                )}
              {!isMember(selectedSociety.name) && !hasApplied(selectedSociety) && (
                  <button onClick={() => handleApply(selectedSociety._id)} className="btn">
                    Apply to Join
                  </button>
              )}
              {hasApplied(selectedSociety) && (
                  <div className="application-status">
                    <p><strong>Application Status:</strong></p>
                    <span className={`badge ${
                      getApplicationStatus(selectedSociety.name) === 'accepted' ? 'badge-success' :
                      getApplicationStatus(selectedSociety.name) === 'rejected' ? 'badge-error' :
                      'badge-warning'
                    }`}>
                      {getApplicationStatus(selectedSociety.name)}
                    </span>
                  </div>
                )}
              </div>
            </div>

            {selectedSociety.posts && selectedSociety.posts.length > 0 && (
              <div className="society-posts card">
              <h3>Recent Posts</h3>
                {selectedSociety.posts.map((post, index) => (
                  <div key={index} className="post-card">
                    <h4>{post.isAnnouncement ? '📢 Announcement' : 'Post'}</h4>
                    <p>{post.content}</p>
                    {post.attachments && post.attachments.length > 0 && (
                      <div className="attachments">
                        <h5>Attachments:</h5>
                        {post.attachments.map((attachment, i) => (
                          <a key={i} href={attachment.fileUrl} target="_blank" rel="noopener noreferrer">
                            {attachment.fileName}
                          </a>
                        ))}
                      </div>
                    )}
                    <div className="comments-section">
                      <h5>Comments</h5>
                      {post.comments && post.comments.map((comment, commentIndex) => (
                        <div key={commentIndex} className="comment">
                          <strong>{comment.author}:</strong> {comment.content}
                          </div>
                      ))}
                      {isMember(selectedSociety.name) && (
                        <div className="add-comment">
                          <textarea
                            value={newComment[index] || ''}
                            onChange={(e) => setNewComment(prev => ({ ...prev, [index]: e.target.value }))}
                            placeholder="Add a comment..."
                            maxLength={300}
                          />
                          <div className="char-count">
                            {(newComment[index] || '').length}/300 characters
                          </div>
                          <button
                            onClick={() => handleComment(selectedSociety._id, index)}
                            className="btn"
                          >
                            Comment
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
            </div>
          )}
        </div>
        ) : (
          <div className="grid">
            {societies.map((society) => {
              const applicationStatus = getApplicationStatus(society.name);
              return (
                <div key={society._id} className="card">
                  <h3>{society.name}</h3>
                  <p>{society.description}</p>
                  <p>Status: {society.isApproved ? 'Active' : 'Pending Approval'}</p>
                  <div className="card-actions">
                    <button onClick={() => handleViewSociety(society)} className="btn">
                      View Details
                    </button>
                    {!hasApplied(society) && society.isApproved && (
                      <button onClick={() => handleApply(society._id)} className="btn">
                        Apply
                      </button>
                    )}
                    {hasApplied(society) && (
                      <span className={`badge ${
                        applicationStatus === 'accepted' ? 'badge-success' :
                        applicationStatus === 'rejected' ? 'badge-error' :
                        'badge-warning'
                      }`}>
                        {applicationStatus === 'requested' ? 'Pending' :
                         applicationStatus.charAt(0).toUpperCase() + applicationStatus.slice(1)}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <style>
        {`
          .society-details-view {
            padding: 1rem 0;
          }

          .btn-back {
            margin-bottom: 1rem;
            background: none;
            border: 1px solid var(--text-gray);
            color: var(--text-white);
          }

          .btn-back:hover {
            border-color: var(--accent-blue);
            color: var(--accent-blue);
            transform: translateX(-5px);
          }

          .society-info {
            margin: 1rem 0;
          }

          .application-status {
            margin-top: 1rem;
          }

          .post-card {
            background: var(--secondary-black);
            padding: 1rem;
            margin: 1rem 0;
            border-radius: 8px;
          }

          .attachments {
            margin: 1rem 0;
          }

          .attachments a {
            display: inline-block;
            margin-right: 1rem;
            color: var(--accent-blue);
            text-decoration: none;
          }

          .attachments a:hover {
            text-decoration: underline;
          }

          .add-comment {
            margin-top: 1rem;
          }

          .add-comment textarea {
            width: 100%;
            margin-bottom: 0.5rem;
            min-height: 80px;
          }
        `}
      </style>
    </div>
  );
}

export default StudentDashboard; 