import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Navbar from './Navbar';
import '../styles/global.css';

function StudentProfile({ user, onLogout }) {
  const [bio, setBio] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [currentPassword, setCurrentPassword] = useState('');
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState('');
  const [message, setMessage] = useState({ text: '', type: '' });

  useEffect(() => {
    // Load user profile data
    const fetchProfile = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/api/students/${user.rollNumber}/profile`);
        setBio(response.data.bio || '');
        if (response.data.profilePhoto) {
          setPreviewUrl(`http://localhost:5000/${response.data.profilePhoto}`);
        }
      } catch (error) {
        setMessage({ text: 'Error loading profile', type: 'error' });
      }
    };
    fetchProfile();
  }, [user.rollNumber]);

  const handleFileSelect = (event) => {
    const file = event.target.files[0];
    if (file) {
      setSelectedFile(file);
      const reader = new FileReader();
      reader.onload = () => setPreviewUrl(reader.result);
      reader.readAsDataURL(file);
    }
  };

  const handleUpdateProfile = async (e) => {
    e.preventDefault();
    try {
      const formData = new FormData();
      formData.append('bio', bio);
      if (selectedFile) {
        formData.append('profilePhoto', selectedFile);
      }

      await axios.put(`http://localhost:5000/api/students/${user.rollNumber}/profile`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });
      setMessage({ text: 'Profile updated successfully!', type: 'success' });
    } catch (error) {
      setMessage({ text: 'Error updating profile', type: 'error' });
    }
  };

  const handleUpdatePassword = async (e) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      setMessage({ text: 'New passwords do not match', type: 'error' });
      return;
    }
    try {
      await axios.put(`http://localhost:5000/api/students/${user.rollNumber}/password`, {
        currentPassword,
        newPassword
      });
      setMessage({ text: 'Password updated successfully!', type: 'success' });
      setNewPassword('');
      setConfirmPassword('');
      setCurrentPassword('');
    } catch (error) {
      setMessage({ text: error.response?.data?.message || 'Error updating password', type: 'error' });
    }
  };

  return (
    <div className="dashboard fade-in">
      <Navbar userType="Student" user={user} onLogout={onLogout} />
      <div className="container fade-in">
        <h2>Profile Settings</h2>
        <h3>Welcome, {user.name}</h3>
        {message.text && (
          <div className={`alert ${message.type === 'success' ? 'badge-success' : 'badge-error'}`}>
            {message.text}
          </div>
        )}

        <div className="grid">
          {/* Profile Info Section */}
          <div className="card">
            <h3>Profile Information</h3>
            <form onSubmit={handleUpdateProfile}>
              <div className="form-group">
                <label>Profile Picture</label>
                <div className="profile-picture">
                  {previewUrl && (
                    <img
                      src={previewUrl}
                      alt="Profile preview"
                      className="profile-image"
                    />
                  )}
                </div>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileSelect}
                  className="file-input"
                />
              </div>
              <div className="form-group">
                <label>Bio</label>
                <textarea
                  className="textarea"
                  value={bio}
                  onChange={(e) => setBio(e.target.value)}
                  placeholder="Tell us about yourself..."
                  maxLength={500}
                />
                <div className="char-count">
                  {bio.length}/500 characters
                </div>
              </div>
              <button type="submit" className="btn">
                Update Profile
              </button>
            </form>
          </div>

          {/* Password Change Section */}
          <div className="card">
            <h3>Change Password</h3>
            <form onSubmit={handleUpdatePassword}>
              <div className="form-group">
                <label>Current Password</label>
                <input
                  type="password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  required
                />
              </div>
              <div className="form-group">
                <label>New Password</label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  required
                />
              </div>
              <div className="form-group">
                <label>Confirm New Password</label>
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                />
              </div>
              <button type="submit" className="btn">
                Update Password
              </button>
            </form>
          </div>
        </div>

        <style>
          {`
            .profile-picture {
              margin-bottom: 1rem;
            }

            .profile-image {
              width: 150px;
              height: 150px;
              object-fit: cover;
              border-radius: 50%;
              margin-bottom: 1rem;
              border: 3px solid var(--accent-blue);
              box-shadow: 0 0 15px rgba(0, 168, 255, 0.3);
              transition: transform var(--transition-speed);
            }

            .profile-image:hover {
              transform: scale(1.05);
            }

            .form-group {
              margin-bottom: 1.5rem;
            }

            .file-input {
              margin-top: 0.5rem;
            }

            .alert {
              padding: 1rem;
              border-radius: 4px;
              margin-bottom: 1.5rem;
            }

            .textarea {
              min-height: 120px;
              resize: vertical;
            }

            .char-count {
              font-size: 0.8rem;
              color: var(--text-gray);
              text-align: right;
              margin-top: 0.25rem;
            }
          `}
        </style>
      </div>
    </div>
  );
}

export default StudentProfile; 