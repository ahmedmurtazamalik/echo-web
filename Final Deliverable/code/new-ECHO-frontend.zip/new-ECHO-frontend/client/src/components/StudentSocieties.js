import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Navbar from './Navbar';
import '../styles/global.css';

function StudentSocieties({ user, onLogout }) {
  const [societies, setSocieties] = useState([]);
  const [applications, setApplications] = useState([]);
  const [selectedSociety, setSelectedSociety] = useState(null);
  const [newComment, setNewComment] = useState({});
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    fetchSocieties();
    fetchMyApplications();
  }, []);

  const fetchSocieties = async () => {
    try {
      const response = await axios.get('http://localhost:5000/api/societies/available');
      setSocieties(response.data);
    } catch (error) {
      alert('Error fetching societies: ' + error.message);
    }
  };

  const fetchMyApplications = async () => {
    try {
      const response = await axios.get(`http://localhost:5000/api/students/${user.name}/applications`);
      setApplications(response.data);
    } catch (error) {
      alert('Error fetching applications: ' + error.message);
    }
  };

  const handleApply = async (societyId) => {
    try {
      await axios.post(`http://localhost:5000/api/students/${user.name}/applications`, {
        societyId
      });
      fetchMyApplications();
      alert('Application submitted successfully!');
    } catch (error) {
      alert('Error submitting application: ' + error.message);
    }
  };

  const handleViewSociety = async (society) => {
    try {
      // Fetch complete society data when viewing details
      const response = await axios.get(`http://localhost:5000/api/societies/${society.name}`);
      console.log('Society data received:', response.data);
      console.log('Posts:', response.data.posts);
      if (response.data.posts && response.data.posts.length > 0) {
        console.log('First post:', response.data.posts[0]);
        console.log('First post createdAt:', response.data.posts[0].createdAt);
        console.log('First post attachments:', response.data.posts[0].attachments);
        if (response.data.posts[0].comments && response.data.posts[0].comments.length > 0) {
          console.log('First comment:', response.data.posts[0].comments[0]);
          console.log('First comment createdAt:', response.data.posts[0].comments[0].createdAt);
        }
      }
      setSelectedSociety(response.data);
      setShowModal(true);
    } catch (error) {
      console.error('Error fetching society details:', error);
      alert('Error fetching society details: ' + error.message);
    }
  };

  const handleComment = async (societyId, postIndex) => {
    try {
      if (!newComment[postIndex]?.trim()) {
        alert('Please enter a comment');
        return;
      }

      await axios.post(`http://localhost:5000/api/students/${user.name}/posts/${societyId}/${postIndex}/comments`, {
        content: newComment[postIndex]
      });

      // Clear the comment input
      setNewComment(prev => ({ ...prev, [postIndex]: '' }));

      // Refresh the society data
      const response = await axios.get(`http://localhost:5000/api/societies/${selectedSociety.name}`);
      setSelectedSociety(response.data);
    } catch (error) {
      alert('Error posting comment: ' + error.message);
    }
  };

  const getApplicationStatus = (societyName) => {
    const application = applications.find(app => app.societyName === societyName);
    if (!application) return null;
    return application.status;
  };

  const isMember = (societyName) => {
    const application = applications.find(app => app.societyName === societyName);
    return application?.status === 'accepted';
  };

  const hasApplied = (society) => {
    const application = applications.find(app => app.societyName === society.name);
    return application !== undefined;
  };

  const getMemberRole = (society, memberName) => {
    if (!society.memberRoles) return null;
    const roleData = society.memberRoles.find(r => r.memberName === memberName);
    return roleData ? roleData.role : null;
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setSelectedSociety(null);
  };

  const handleModalClick = (e) => {
    if (e.target.classList.contains('modal')) {
      handleCloseModal();
    }
  };

  const handleDeleteComment = async (societyId, postIndex, commentIndex) => {
    try {
      await axios.delete(`http://localhost:5000/api/students/${user.name}/posts/${societyId}/${postIndex}/comments/${commentIndex}`);
      
      // Fetch updated society data
      const response = await axios.get(`http://localhost:5000/api/societies/${selectedSociety.name}`);
      setSelectedSociety(response.data);
      
    } catch (error) {
      alert('Error deleting comment: ' + error.message);
    }
  };

  const getFileIcon = (fileType) => {
    switch (fileType) {
      case 'image/png':
      case 'image/jpeg':
      case 'image/gif':
        return '📷';
      case 'application/pdf':
        return '📄';
      case 'text/plain':
        return '📄';
      default:
        return '📄';
    }
  };

  return (
    <div className="dashboard fade-in">
      <Navbar userType="Student" user={user} onLogout={onLogout} />
      
      <div className="container">
        <div className="grid">
          {societies.map((society) => {
            const applicationStatus = getApplicationStatus(society.name);
            return (
              <div key={society._id} className="card">
                <h3>{society.name}</h3>
                <p>{society.description}</p>
                <p>Status: {society.isApproved ? 'Active' : 'Pending Approval'}</p>
                <div className="card-actions">
                  <button onClick={() => handleViewSociety(society)} className="btn">
                    View Details
                  </button>
                  {!hasApplied(society) && society.isApproved && (
                    <button onClick={() => handleApply(society._id)} className="btn">
                      Apply
                    </button>
                  )}
                  {hasApplied(society) && (
                    <span className={`badge ${
                      applicationStatus === 'accepted' ? 'badge-success' :
                      applicationStatus === 'rejected' ? 'badge-error' :
                      'badge-warning'
                    }`}>
                      {applicationStatus === 'requested' ? 'Pending' :
                       applicationStatus.charAt(0).toUpperCase() + applicationStatus.slice(1)}
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Society Details Modal */}
        {showModal && selectedSociety && (
          <div className="modal" onClick={handleModalClick}>
            <div className="modal-content card" onClick={(e) => e.stopPropagation()}>
              <div className="modal-header">
                <h2>{selectedSociety.name}</h2>
                <button className="btn-close" onClick={handleCloseModal}>×</button>
              </div>
              <div className="society-details">
                <p><strong>Description:</strong> {selectedSociety.description}</p>
                <p><strong>Category:</strong> {selectedSociety.category}</p>
                <p><strong>Members:</strong> {selectedSociety.members.length}</p>
                {isMember(selectedSociety.name) && (
                  <p><strong>Your Role:</strong> {getMemberRole(selectedSociety, user.name) || 'Member'}</p>
                )}
                {!isMember(selectedSociety.name) && !hasApplied(selectedSociety) && (
                  <button onClick={() => handleApply(selectedSociety._id)} className="btn">
                    Apply to Join
                  </button>
                )}

                {/* Posts Section */}
                {selectedSociety.posts && selectedSociety.posts.length > 0 && (
                  <div className="posts-section">
                    <h3>Posts</h3>
                    {selectedSociety.posts.map((post, index) => (
                      <div key={index} className="post-card">
                        <h4>{post.isAnnouncement ? '📢 Announcement' : 'Post'}</h4>
                        <p>{post.content}</p>
                        <small className="post-timestamp">Posted on: {new Date(post.createdAt).toLocaleString()}</small>
                        {post.attachments && post.attachments.length > 0 && (
                          <div className="attachments-section">
                            <h5>Attachments:</h5>
                            {post.attachments.map((attachment, i) => (
                              <div key={i} className="attachment">
                                {attachment.fileType && attachment.fileType.startsWith('image/') ? (
                                  <div className="image-preview">
                                    <img 
                                      src={attachment.fileUrl} 
                                      alt={attachment.fileName} 
                                      className="post-image"
                                    />
                                  </div>
                                ) : (
                                  <a href={attachment.fileUrl} target="_blank" rel="noopener noreferrer">
                                    {getFileIcon(attachment.fileType)} {attachment.fileName}
                                  </a>
                                )}
                              </div>
                            ))}
                          </div>
                        )}
                        <div className="comments-section">
                          <h5>Comments</h5>
                          {post.comments && post.comments.map((comment, commentIndex) => (
                            <div key={commentIndex} className="comment-card">
                              <div className="comment-content">
                                <strong>{comment.author}:</strong> {comment.content}
                                <small className="comment-timestamp">
                                  {new Date(comment.createdAt).toLocaleString()}
                                </small>
                              </div>
                              {comment.author === user.name && (
                                <button 
                                  className="delete-comment-btn"
                                  onClick={() => handleDeleteComment(selectedSociety._id, index, commentIndex)}
                                  title="Delete comment"
                                >
                                  ×
                                </button>
                              )}
                            </div>
                          ))}
                          {isMember(selectedSociety.name) && (
                            <div className="add-comment">
                              <textarea
                                value={newComment[index] || ''}
                                onChange={(e) => setNewComment(prev => ({ ...prev, [index]: e.target.value }))}
                                placeholder="Add a comment..."
                                maxLength={300}
                              />
                              <div className="char-count">
                                {(newComment[index] || '').length}/300 characters
                              </div>
                              <button 
                                onClick={() => handleComment(selectedSociety._id, index)}
                                className="btn"
                              >
                                Comment
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default StudentSocieties; 