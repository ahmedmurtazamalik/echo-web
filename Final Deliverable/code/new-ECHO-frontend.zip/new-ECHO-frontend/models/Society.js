const mongoose = require('mongoose');

const societySchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    unique: true,
    maxlength: 50
  },
  description: {
    type: String,
    required: true,
    maxlength: 500
  },
  category: {
    type: String,
    required: true,
    maxlength: 50
  },
  isApproved: {
    type: Boolean,
    default: false
  },
  members: [{
    type: String  // Will store student names
  }],
  memberRoles: [{
    memberName: String,
    role: {
      type: String,
      maxlength: 50
    }
  }],
  memberHistory: [{
    memberName: String,
    action: {
      type: String,
      enum: ['joined', 'left', 'role_assigned', 'role_removed', 'event_attended', 'event_organized']
    },
    details: {
      type: String,
      maxlength: 200
    },
    timestamp: {
      type: Date,
      default: Date.now
    }
  }],
  posts: [{
    content: {
      type: String,
      required: true,
      maxlength: 1000
    },
    isAnnouncement: Boolean,
    scheduledFor: Date,  // For scheduled announcements
    createdAt: {
      type: Date,
      default: Date.now
    },
    lastEdited: {
      type: Date,
      default: Date.now
    },
    editedBy: String,
    attachments: [{
      fileName: String,
      fileUrl: String,
      fileType: String,
      uploadedAt: {
        type: Date,
        default: Date.now
      }
    }],
    comments: [{
      author: String,
      content: {
        type: String,
        required: true,
        maxlength: 300
      },
      createdAt: {
        type: Date,
        default: Date.now
      }
    }]
  }],
  events: [{
    name: {
      type: String,
      required: true,
      maxlength: 100
    },
    description: {
      type: String,
      required: true,
      maxlength: 500
    },
    date: {
      type: Date,
      required: true
    },
    startTime: {
      type: String,
      required: true
    },
    endTime: {
      type: String,
      required: true
    },
    venue: {
      type: String,
      required: true
    },
    status: {
      type: String,
      enum: ['pending', 'approved', 'rejected'],
      default: 'pending'
    },
    createdAt: {
      type: Date,
      default: Date.now
    },
    comments: [{
      author: String,
      content: {
        type: String,
        required: true,
        maxlength: 300
      },
      createdAt: {
        type: Date,
        default: Date.now
      }
    }]
  }],
  venues: [{
    name: {
      type: String,
      required: true,
      maxlength: 100
    },
    capacity: {
      type: Number,
      required: true
    },
    location: {
      type: String,
      required: true,
      maxlength: 200
    },
    isAvailable: {
      type: Boolean,
      default: true
    },
    reservations: [{
      eventId: mongoose.Schema.Types.ObjectId,
      date: Date,
      startTime: String,
      endTime: String,
      status: {
        type: String,
        enum: ['pending', 'approved', 'rejected'],
        default: 'pending'
      }
    }]
  }]
});

module.exports = mongoose.model('Society', societySchema); 