const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  rollNumber: {
    type: String,
    required: true,
    unique: true,
    validate: {
      validator: function(v) {
        // Allow special roll numbers for admin and society accounts
        if (this.type === 'Admin' || this.type === 'Society') {
          return true;
        }
        // For students, validate roll number format: <city character><batch number><four digit number>
        return /^[a-z]\d{6}$/.test(v);
      },
      message: props => `${props.value} is not a valid roll number!`
    }
  },
  password: {
    type: String,
    required: true
  },
  name: {
    type: String,
    default: ''
  },
  bio: {
    type: String,
    default: ''
  },
  profilePhoto: {
    type: String,
    default: ''
  },
  type: {
    type: String,
    enum: ['Student', 'Admin', 'Society'],
    required: true
  },
  applications: [{
    societyName: String,
    status: {
      type: String,
      enum: ['requested', 'accepted', 'rejected'],
      default: 'requested'
    }
  }]
});

module.exports = mongoose.model('User', userSchema); 